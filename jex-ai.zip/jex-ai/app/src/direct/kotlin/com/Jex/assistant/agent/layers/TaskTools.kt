package com.Jex.assistant.agent.layers

import android.content.Context
import com.Jex.assistant.action.ActionExecutor
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object TaskTools {
    @Volatile private var manager: TaskManager? = null

    fun manager(ctx: Context): TaskManager = manager ?: synchronized(this) {
        manager ?: TaskManager(
            executor = StepExecutor { step -> ActionExecutor.executeDirect(ctx.applicationContext, step.tool, step.args) },
            planner = { goal -> withContext(Dispatchers.IO) { Planner.plan(ctx.applicationContext, goal) } },
            onSpeak = { VoiceSessionManager.say("[Task] $it") },
            onFinished = { VoiceSessionManager.say("[Task] Task '${it.goal.take(40)}' ${it.state.name.lowercase()}: ${it.result}. Tell the user in one short sentence.") }
        ).also { manager = it }
    }

    val NAMES = setOf("run_task", "task_status", "pause_task", "resume_task", "cancel_task", "list_tasks", "confirm_task", "stop_everything")

    fun execute(ctx: Context, name: String, args: JSONObject): JSONObject {
        val m = manager(ctx)
        val id = args.optString("task_id").takeIf { it.isNotBlank() }
        return when (name) {
            "run_task" -> m.start(args.optString("goal"))
            "task_status" -> m.status(id)
            "pause_task" -> m.pause(id)
            "resume_task" -> m.resume(id)
            "confirm_task" -> m.confirm(id)
            "cancel_task" -> if (args.optBoolean("all")) m.cancelAll() else m.cancel(id)
            "stop_everything" -> m.cancelAll()
            "list_tasks" -> m.list()
            else -> ToolResults.unknown(name)
        }
    }
}
