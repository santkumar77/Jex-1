package com.Jex.assistant.callagent

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.Jex.assistant.action.CommIntents
import com.Jex.assistant.action.ContactResolver
import com.Jex.assistant.action.ContactResult
import com.Jex.assistant.action.ScreenDrivers
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.action.functionDecl
import com.Jex.assistant.data.ApiKeyStore
import com.Jex.assistant.data.JexPreferences
import com.Jex.assistant.voice.EchoGuard
import com.Jex.assistant.voice.GeminiLiveClient
import com.Jex.assistant.voice.LiveAudioIO
import com.Jex.assistant.voice.VoiceForegroundService
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Thin telephony boundary so the call flow can be tested with a fake. */
interface CallTelephony {
    fun dial(number: String): Boolean
    suspend fun waitForOffhook(timeoutMs: Long): Boolean
    fun speakerOn(on: Boolean): Boolean
    fun hangUp(): Boolean
}

class RealTelephony(private val ctx: Context) : CallTelephony {
    private val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile private var offhook = false
    private var callback: Any? = null

    @SuppressLint("MissingPermission")
    override fun dial(number: String): Boolean {
        offhook = false
        registerListener()
        return CommIntents.call(ctx, number) == "calling"
    }

    @SuppressLint("MissingPermission")
    private fun registerListener() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) { offhook = true; return }
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) { if (state == TelephonyManager.CALL_STATE_OFFHOOK) offhook = true }
            }
            callback = cb
            tm.registerTelephonyCallback(ctx.mainExecutor, cb)
        } else {
            @Suppress("DEPRECATION")
            val l = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) { if (state == TelephonyManager.CALL_STATE_OFFHOOK) offhook = true }
            }
            callback = l
            @Suppress("DEPRECATION") tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    override suspend fun waitForOffhook(timeoutMs: Long): Boolean {
        var waited = 0L
        while (waited < timeoutMs) { if (offhook) return true; delay(250); waited += 250 }
        return offhook
    }

    override fun speakerOn(on: Boolean): Boolean {
        return try {
            am.mode = if (on) AudioManager.MODE_IN_COMMUNICATION else AudioManager.MODE_NORMAL
            @Suppress("DEPRECATION") run { am.isSpeakerphoneOn = on }
            if (on) {
                // OEMs that block it: press the speaker button through accessibility
                ScreenDrivers.current.let { d -> if (d.isAvailable() && !am.isSpeakerphoneOn) d.clickText("Speaker") }
            }
            true
        } catch (ignored: Exception) { false }
    }

    @SuppressLint("MissingPermission")
    override fun hangUp(): Boolean {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
            ) {
                val t = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                @Suppress("DEPRECATION") if (t.endCall()) return true
            }
        } catch (ignored: Exception) {}
        val d = ScreenDrivers.current
        return d.isAvailable() && (d.clickText("End call") || d.clickText("End"))
    }

    fun release() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31) (callback as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            else @Suppress("DEPRECATION") (callback as? PhoneStateListener)?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (ignored: Exception) {}
    }
}

data class CallUi(val active: Boolean = false, val state: CallState = CallState.IDLE, val contact: String = "", val note: String = "")

/** "Jaswant ko phone karke bol de ..." Best-effort speakerphone loop. Always discloses it is Jex AI. */
object CallAgent {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _ui = MutableStateFlow(CallUi())
    val ui: StateFlow<CallUi> = _ui
    @Volatile private var endRequested = false
    @Volatile private var running = false

    const val REALITY_CHECK =
        "Android does not let an app inject or read the audio of a normal cellular call. Jex uses the SPEAKERPHONE LOOP: it places the call, " +
            "turns the speakerphone on, speaks through the phone's speaker and listens through the mic. It is best-effort: quality depends on the device, " +
            "volume and noise. If the audio is unusable Jex offers to send a WhatsApp/SMS message instead."

    val declaration get() = functionDecl(
        "call_and_talk", "Call a person and talk to them on the user's behalf (Jex AI introduces itself as an AI). Use only after a clear instruction like 'phone karke bol de'.",
        mapOf("contact_or_number" to "Contact name or phone number", "purpose" to "Why we are calling", "key_points" to "Comma separated facts it may share", "language" to "Language to speak", "max_minutes" to "Max minutes, default 5"),
        listOf("contact_or_number", "purpose")
    )

    private fun callsToday(ctx: Context): Int {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        return if (JexPreferences.getString(ctx, JexPreferences.Keys.CALL_COUNT_DAY) == today) JexPreferences.getInt(ctx, JexPreferences.Keys.CALL_COUNT) else 0
    }

    private fun bumpCalls(ctx: Context) {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        JexPreferences.putString(ctx, JexPreferences.Keys.CALL_COUNT_DAY, today)
        JexPreferences.putInt(ctx, JexPreferences.Keys.CALL_COUNT, callsToday(ctx) + 1)
    }

    fun endNow() { endRequested = true }

    fun start(ctx: Context, args: JSONObject): JSONObject {
        val app = ctx.applicationContext
        if (running) return ToolResults.status("already_on_a_call")
        val query = args.optString("contact_or_number")
        val purpose = args.optString("purpose")
        if (query.isBlank() || purpose.isBlank()) return ToolResults.error("contact_or_number and purpose are required")
        val matches = ContactResolver.matches(app, query)
        if (!ContactResolver.looksLikePhoneNumber(query) && matches.size > 1 && matches.none { it.name.equals(query.trim(), true) }) {
            return ToolResults.status("contact_ambiguous", "Ask the user which one: " + matches.joinToString { it.name })
        }
        val found = when (val r = ContactResolver.lookup(app, query)) {
            is ContactResult.Found -> r
            is ContactResult.NoPermission -> return ToolResults.status("needs_contacts_permission")
            is ContactResult.NotFound -> return ToolResults.status("contact_not_found")
        }
        CallPolicy.mayCall(found.number, namedByUser = true, callsToday = callsToday(app))?.let { return ToolResults.status("refused", it) }
        val points = args.optString("key_points").split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
        val minutes = args.optString("max_minutes").toIntOrNull()?.coerceIn(1, 10) ?: 5
        running = true
        endRequested = false
        bumpCalls(app)
        scope.launch { runCall(app, found.name, found.number, purpose, points, args.optString("language").ifBlank { "Hindi/Hinglish" }, minutes, RealTelephony(app)) }
        return JSONObject().put("status", "calling").put("contact", found.name)
    }

    private suspend fun runCall(ctx: Context, name: String, number: String, purpose: String, points: List<String>, language: String, minutes: Int, tel: RealTelephony) {
        val machine = CallStateMachine()
        val transcript = StringBuilder()
        val userName = JexPreferences.getString(ctx, JexPreferences.Keys.USER_NAME).ifBlank { "the user" }
        var client: GeminiLiveClient? = null
        var audio: LiveAudioIO? = null
        var summary = ""
        try {
            // free the microphone: the main session pauses while the call session runs
            val wasActive = VoiceSessionManager.isActive.value
            if (wasActive) VoiceForegroundService.stop(ctx)
            delay(600)
            _ui.value = CallUi(true, CallState.DIALING, name)
            machine.moveTo(CallState.DIALING)
            if (!tel.dial(number)) { machine.moveTo(CallState.FAILED); summary = "I couldn't place the call."; return }
            if (!tel.waitForOffhook(15_000)) { machine.moveTo(CallState.ENDING); machine.moveTo(CallState.SUMMARY); summary = "The call did not start."; return }
            machine.moveTo(CallState.RINGING); _ui.value = _ui.value.copy(state = CallState.RINGING)
            tel.speakerOn(true)
            EchoGuard.reset(); EchoGuard.strict = true

            val ready = kotlinx.coroutines.CompletableDeferred<Boolean>()
            val endDecl = JSONArray().put(functionDecl("end_call", "End the phone call politely once the purpose is done."))
            val c = GeminiLiveClient(ApiKeyStore.getKey(ctx))
            client = c
            var farVoice = 0
            var playing = false
            val a = LiveAudioIO(onMicChunk = { bytes -> if (!EchoGuard.isMicMuted() && c.isReady) c.sendAudio(bytes) }, onMicAmplitude = { rms -> if (rms > 0.03f && !EchoGuard.isMicMuted()) farVoice++ })
            audio = a
            c.listener = object : GeminiLiveClient.Listener {
                override fun onSetupComplete() { ready.complete(true) }
                override fun onAudioChunk(bytes: ByteArray) {
                    if (!playing) { playing = true; EchoGuard.notifyPlaybackStarted() }
                    a.playChunk(bytes)
                }
                override fun onInputTranscript(text: String) { transcript.append("Them: ").append(text).append('\n') }
                override fun onOutputTranscript(text: String) { transcript.append("Jex: ").append(text).append('\n') }
                override fun onToolCall(id: String, name: String, args: JSONObject) {
                    if (name == "end_call") { endRequested = true; c.sendToolResponse(id, name, JSONObject().put("status", "ending")) }
                }
                override fun onTurnComplete() { if (playing) { playing = false; EchoGuard.notifyPlaybackStopped() } }
                override fun onInterrupted() { a.flushPlayback(); if (playing) { playing = false; EchoGuard.notifyPlaybackStopped() } }
                override fun onError(message: String) { endRequested = true }
                override fun onClosed() {}
            }
            c.connect(CallPolicy.systemPrompt(userName, purpose, points, language), tools = endDecl)
            if (!ready.await()) { summary = "I couldn't start the call assistant."; return }
            if (!a.startMic()) { summary = "The microphone was not available for the call."; return }

            // CONNECTED = the other person's voice is heard (cellular OFFHOOK fires while still dialing)
            var waited = 0L
            while (farVoice < 3 && waited < CallPolicy.NO_ANSWER_MS && !endRequested) { delay(250); waited += 250 }
            if (farVoice < 3) { summary = "Nobody answered within 45 seconds."; return }
            machine.moveTo(CallState.CONNECTED); machine.moveTo(CallState.TALKING)
            _ui.value = _ui.value.copy(state = CallState.TALKING)
            c.sendText("[Call connected] The other person has answered. Say your opening line now.")

            val deadline = System.currentTimeMillis() + minutes * 60_000L
            while (!endRequested && System.currentTimeMillis() < deadline) delay(300)
        } catch (e: IllegalCallTransition) {
            summary = "The call had an unexpected state."
        } catch (e: Exception) {
            summary = "The call ended with an error."
        } finally {
            _ui.value = _ui.value.copy(state = CallState.ENDING)
            try { client?.let { it.listener = null; it.disconnect() } } catch (ignored: Exception) {}
            try { audio?.release() } catch (ignored: Exception) {}
            tel.hangUp(); tel.speakerOn(false); tel.release()
            EchoGuard.reset()
            _ui.value = CallUi(false, CallState.SUMMARY, name)
            running = false
            // bring the main assistant back and let it tell the user what happened
            VoiceForegroundService.start(ctx)
            val text = transcript.toString().takeLast(1500)
            VoiceSessionManager.say(
                "[Call finished with $name] " + (if (summary.isNotBlank()) "Result: $summary " else "") +
                    (if (text.isNotBlank()) "Transcript:\n$text\n" else "") +
                    "Tell the user in 1-2 sentences what was said and agreed. If the audio was unusable, offer to send a WhatsApp/SMS message instead."
            )
        }
    }
}
