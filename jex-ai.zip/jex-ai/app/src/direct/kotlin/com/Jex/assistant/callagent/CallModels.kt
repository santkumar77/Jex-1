package com.Jex.assistant.callagent

import com.Jex.assistant.data.AssistantBrand

enum class CallState { IDLE, DIALING, RINGING, CONNECTED, TALKING, ENDING, SUMMARY, FAILED }

class IllegalCallTransition(a: CallState, b: CallState) : IllegalStateException("Illegal call transition $a -> $b")

class CallStateMachine {
    var state = CallState.IDLE; private set
    private val allowed = mapOf(
        CallState.IDLE to setOf(CallState.DIALING),
        CallState.DIALING to setOf(CallState.RINGING, CallState.CONNECTED, CallState.ENDING),
        CallState.RINGING to setOf(CallState.CONNECTED, CallState.ENDING),
        CallState.CONNECTED to setOf(CallState.TALKING, CallState.ENDING),
        CallState.TALKING to setOf(CallState.ENDING),
        CallState.ENDING to setOf(CallState.SUMMARY),
        CallState.SUMMARY to emptySet(),
        CallState.FAILED to emptySet()
    )
    fun moveTo(next: CallState) {
        if (next == CallState.FAILED && state != CallState.SUMMARY && state != CallState.FAILED) { state = next; return }
        if (allowed[state]?.contains(next) != true) throw IllegalCallTransition(state, next)
        state = next
    }
}

/** Safety rules: only numbers the user named, no premium-rate numbers, daily limit. Pure. */
object CallPolicy {
    const val DAILY_LIMIT = 10
    const val NO_ANSWER_MS = 45_000L

    private val premiumPrefixes = listOf("+1900", "+1976", "+44909", "+44908", "+44871", "+49900", "+49137", "+33899")

    fun isPremiumRate(number: String): Boolean {
        val n = number.filter { it.isDigit() || it == '+' }
        return premiumPrefixes.any { n.startsWith(it) }
    }

    fun mayCall(number: String, namedByUser: Boolean, callsToday: Int): String? = when {
        !namedByUser -> "Only numbers the user named can be called"
        isPremiumRate(number) -> "That looks like a premium-rate number, so I won't call it"
        callsToday >= DAILY_LIMIT -> "Daily call limit reached"
        else -> null
    }

    fun disclosureLine(userName: String) = "Namaste, main ${AssistantBrand.FULL_NAME} hoon, $userName ki taraf se baat kar raha hoon."

    fun systemPrompt(userName: String, purpose: String, keyPoints: List<String>, language: String): String =
        "You are ${AssistantBrand.FULL_NAME} calling on behalf of $userName. Start by saying exactly: '${disclosureLine(userName)}' " +
            "Then state the purpose clearly and briefly: $purpose. Key points you may share: ${keyPoints.joinToString("; ").ifBlank { "none" }}. " +
            "Answer the other person's questions using only these key points and say you will pass anything else to $userName. " +
            "Be polite, short, and speak in the other person's language (default: $language). Never impersonate $userName, never claim to be human, " +
            "never agree to payments, never share OTPs or sensitive details, and end the call politely when the purpose is done."
}
