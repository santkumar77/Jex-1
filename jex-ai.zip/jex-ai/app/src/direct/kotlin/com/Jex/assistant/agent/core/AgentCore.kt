package com.Jex.assistant.agent.core

import com.Jex.assistant.action.ScreenDriver
import kotlinx.coroutines.delay

enum class Blocker { LOGIN, CAPTCHA, TWO_FACTOR, SECURITY_CHECK, PERMISSION_PROMPT }
enum class FailureReason { NOT_FOUND, STALE, UNSUPPORTED, ACTION_FAILED, VERIFY_FAILED, APP_NOT_OPEN, TIMEOUT }
enum class ExecPhase { IDLE, OBSERVING, RESOLVING, EXECUTING, VERIFYING }
enum class ActionMethod { ACCESSIBILITY_CLICK, GESTURE_ON_ELEMENT_BOUNDS, VISION_TAP, SET_TEXT }

enum class DriverResult { OK, FAILED, STALE, NOT_FOUND, UNSUPPORTED }

data class UiElement(val label: String, val kind: String) {
    val isInput get() = kind == "input"
    val isButton get() = kind == "button"
}

data class ScreenObservation(
    val observationId: Long,
    val packageName: String?,
    val elements: List<UiElement>,
    val windowStamp: Long
) {
    fun has(text: String) = elements.any { it.label.contains(text, ignoreCase = true) }
}

sealed class ActionResult {
    object Success : ActionResult()
    data class Failed(val reason: FailureReason, val detail: String = "") : ActionResult()
    data class Blocked(val blocker: Blocker) : ActionResult()
}

/** Turns driver lines ("[button] Send") into an observation with a monotonically increasing id. */
class ScreenObserver(private val driver: ScreenDriver) {
    @Volatile var latestId = 0L; private set

    fun observe(max: Int = 60): ScreenObservation {
        val lines = driver.readScreenLines(max, 60)
        val elements = lines.map { l ->
            val kind = when {
                l.startsWith("[input]") -> "input"
                l.startsWith("[button]") -> "button"
                else -> "text"
            }
            UiElement(l.substringAfter("] ").trim(), kind)
        }
        latestId++
        return ScreenObservation(latestId, driver.currentPackage(), elements, System.currentTimeMillis())
    }

    fun isLatest(obs: ScreenObservation) = obs.observationId == latestId
}

/** spec -> best element: exact label > startsWith > contains; buttons win ties. */
object TargetResolver {
    fun resolve(obs: ScreenObservation, spec: String): UiElement? {
        val q = spec.trim().lowercase()
        if (q.isEmpty()) return null
        fun score(e: UiElement): Int {
            val l = e.label.lowercase()
            val base = when {
                l == q -> 0
                l.startsWith(q) -> 10
                l.contains(q) -> 20
                else -> 100
            }
            return base + if (e.isButton) 0 else 3
        }
        return obs.elements.filter { score(it) < 100 }.minByOrNull(::score)
    }

    /** Returns >1 when several elements match equally well (ambiguous). */
    fun matchCount(obs: ScreenObservation, spec: String): Int = obs.elements.count { it.label.contains(spec.trim(), ignoreCase = true) }
}

/** Executes one UI action and verifies the expectation afterwards (target gone / text present). */
class UiActionExecutor(private val driver: ScreenDriver, private val observer: ScreenObserver) {
    suspend fun click(obs: ScreenObservation, label: String, expectGone: Boolean = false, expectText: String? = null, settleMs: Long = 500): ActionResult {
        if (!observer.isLatest(obs)) return ActionResult.Failed(FailureReason.STALE)
        val target = TargetResolver.resolve(obs, label) ?: return ActionResult.Failed(FailureReason.NOT_FOUND, label)
        if (!driver.clickText(target.label)) return ActionResult.Failed(FailureReason.ACTION_FAILED, label)
        delay(settleMs)
        val after = observer.observe()
        if (expectGone && TargetResolver.resolve(after, label) != null) return ActionResult.Failed(FailureReason.VERIFY_FAILED, "$label still visible")
        if (expectText != null && !after.has(expectText)) return ActionResult.Failed(FailureReason.VERIFY_FAILED, "expected '$expectText'")
        return ActionResult.Success
    }
}

class TextInputExecutor(private val driver: ScreenDriver, private val observer: ScreenObserver) {
    suspend fun type(text: String, settleMs: Long = 300): ActionResult {
        if (!driver.typeText(text)) return ActionResult.Failed(FailureReason.ACTION_FAILED, "no input field")
        delay(settleMs)
        val after = observer.observe()
        return if (after.has(text.take(20))) ActionResult.Success else ActionResult.Failed(FailureReason.VERIFY_FAILED, "typed text not visible")
    }
}
