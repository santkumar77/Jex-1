package com.Jex.assistant.share

import android.content.Context
import android.content.Intent
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.vision.FrameSourceArbiter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

/** Screen share runs until the USER stops it. There is no auto-timeout and the model cannot stop it. */
object ScreenShareController {
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice

    fun setActive(v: Boolean) { _active.value = v; if (!v) FrameSourceArbiter.stop(FrameSourceArbiter.Source.SCREEN) }
    fun postNotice(msg: String?) { _notice.value = msg }

    fun requestStart(ctx: Context): JSONObject {
        if (_active.value) return ToolResults.status("already_sharing")
        ctx.startActivity(Intent(ctx, ScreenCaptureConsentActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ToolResults.status("waiting_for_user_consent", "Ask the user to tap Start now on the screen-capture dialog")
    }

    /** Called from the user's own actions (stop chip, notification action, or spoken command). */
    fun stop(ctx: Context) {
        ctx.startService(Intent(ctx, ScreenShareService::class.java).setAction(ScreenShareService.ACTION_STOP))
    }
}
