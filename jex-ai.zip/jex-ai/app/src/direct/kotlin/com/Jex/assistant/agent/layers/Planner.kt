package com.Jex.assistant.agent.layers

import android.content.Context
import com.Jex.assistant.data.ApiKeyStore
import com.Jex.assistant.voice.ChatReplyResult
import com.Jex.assistant.voice.ChatTurn
import com.Jex.assistant.voice.GeminiTextClient
import org.json.JSONArray
import org.json.JSONObject

/** Layer 1: turns the user's raw sentence into at most 25 steps with the model (JSON only). Nothing is keyword-routed. */
object Planner {
    private const val SYSTEM = "You are the planner of a phone assistant. Convert the user's goal into an ordered JSON plan. " +
        "Output ONLY JSON: {\"steps\":[{\"tool\":string,\"args\":object,\"expectation\":string?}]}. At most 25 steps. " +
        "Allowed tools: open_app(app_name), go_home, go_back, read_screen, click_text(text), scroll(direction), type_text(text), whatsapp_open, " +
        "whatsapp_search(name), whatsapp_message(name,text), whatsapp_call(name), call_contact(name_or_number), sms_send(name_or_number,text), " +
        "set_flashlight(on), volume_set(percent), set_wifi(on), set_bluetooth(on), brightness_change(direction), take_photo(camera). " +
        "expectation is optional, like \"text:Search\" or \"gone:Loading\". Never invent personal data. No commentary."

    fun parse(json: String): List<PlanStep> {
        val clean = json.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val arr = JSONObject(clean).optJSONArray("steps") ?: JSONArray()
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val tool = o.optString("tool").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                PlanStep(tool, o.optJSONObject("args") ?: JSONObject(), o.optString("expectation").takeIf { it.isNotBlank() }, ConfirmationPolicy.riskOf(tool))
            }.take(TaskManager.MAX_PLAN_STEPS)
        } catch (ignored: Exception) { emptyList() }
    }

    fun plan(ctx: Context, goal: String): List<PlanStep> {
        val r = GeminiTextClient.reply(ApiKeyStore.getKey(ctx), SYSTEM, listOf(ChatTurn(true, goal)))
        return if (r is ChatReplyResult.Success) parse(r.text) else emptyList()
    }
}
