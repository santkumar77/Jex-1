package com.Jex.assistant.action

import android.accessibilityservice.AccessibilityService
import android.content.ContentProviderOperation
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import com.Jex.assistant.agent.layers.TaskTools
import com.Jex.assistant.agent.social.SocialAgent
import com.Jex.assistant.agent.whatsapp.WhatsAppAgent
import com.Jex.assistant.callagent.CallAgent
import com.Jex.assistant.data.ContactStore
import com.Jex.assistant.license.AccessKeyManager
import com.Jex.assistant.notify.NotificationTools
import com.Jex.assistant.share.FormGuideController
import com.Jex.assistant.share.ScreenShareController
import com.Jex.assistant.vision.VisionTools
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

object ActionExecutor {

    /** Entry used by the live voice session: refuses when the access key is not active. */
    suspend fun execute(ctx: Context, name: String, args: JSONObject): JSONObject {
        val app = ctx.applicationContext
        if (!AccessKeyManager.isActive(app)) return ToolResults.status("blocked", AccessKeyManager.blockedMessage(app))
        return executeDirect(app, name, args)
    }

    private fun needsA11y(): JSONObject? =
        if (!ScreenDrivers.current.isAvailable()) ToolResults.status("accessibility_not_enabled", "Ask the user to turn on Jex AI screen control in Settings > Accessibility") else null

    private fun bool(args: JSONObject, key: String): Boolean = args.optString(key).lowercase().let { it == "true" || it == "on" || it == "yes" || it == "1" } || args.optBoolean(key)

    suspend fun executeDirect(ctx: Context, name: String, args: JSONObject): JSONObject {
        val app = ctx.applicationContext
        val d = ScreenDrivers.current
        if (name in VisionTools.NAMES) return VisionTools.execute(app, name, args)
        if (name in TaskTools.NAMES) return TaskTools.execute(app, name, args)
        return when (name) {
            "open_app" -> openApp(app, args.optString("app_name"))
            "go_home" -> needsA11y() ?: global(d, AccessibilityService.GLOBAL_ACTION_HOME)
            "go_back" -> needsA11y() ?: global(d, AccessibilityService.GLOBAL_ACTION_BACK)
            "recent_apps" -> needsA11y() ?: global(d, AccessibilityService.GLOBAL_ACTION_RECENTS)
            "open_notifications" -> needsA11y() ?: global(d, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> needsA11y() ?: global(d, AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            "lock_screen" -> needsA11y() ?: global(d, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "take_screenshot" -> needsA11y() ?: global(d, AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "read_screen" -> needsA11y() ?: JSONObject().put("status", "ok").put("screen", JSONArray(d.readScreenLines(40, 40)))
            "read_screen_detailed" -> needsA11y() ?: JSONObject().put("status", "ok").put("screen", JSONArray(d.readScreenDetailed()))
            "click_text", "tap_text" -> needsA11y() ?: ToolResults.status(if (d.clickText(args.optString("text"))) "tapped" else "element_not_found")
            "click_any_button" -> needsA11y() ?: clickAny(d)
            "scroll" -> needsA11y() ?: ToolResults.status(d.scroll(args.optString("direction").lowercase()))
            "swipe" -> needsA11y() ?: ToolResults.status(if (d.swipe(args.optString("direction").lowercase())) "done" else "failed")
            "type_text" -> needsA11y() ?: ToolResults.status(if (d.typeText(args.optString("text"))) "typed" else "no_focused_field")
            "tap_at" -> needsA11y() ?: ToolResults.status(if (d.tapAt(args.optString("x").toIntOrNull() ?: 0, args.optString("y").toIntOrNull() ?: 0)) "done" else "failed")

            "whatsapp_open" -> if (CommIntents.whatsAppPackage(app)?.let { AppLauncher.launch(app, it) } == true) ToolResults.status("done") else ToolResults.status("whatsapp_not_installed")
            "whatsapp_search" -> whatsAppSearch(app, d, args.optString("name"))
            "whatsapp_message" -> WhatsAppAgent.execute(app, JSONObject().put("action", "send_message").put("contact", args.optString("name")).put("text", args.optString("text")))
            "whatsapp_call" -> whatsAppCall(app, d, args.optString("name"), video = false)
            "whatsapp_video_call" -> whatsAppCall(app, d, args.optString("name"), video = true)
            "execute_whatsapp_task" -> WhatsAppAgent.execute(app, args)
            "whatsapp_task_control" -> ToolResults.status("ok")
            "execute_social_media_task" -> SocialAgent.start(app, args)
            "social_media_task_control" -> SocialAgent.control(args.optString("command"), args.optString("task_id").takeIf { it.isNotBlank() })

            "call_contact" -> callContact(app, args.optString("name_or_number"))
            "call_and_talk" -> CallAgent.start(app, args)
            "sms_send" -> smsSend(app, d, args.optString("name_or_number"), args.optString("text"))
            "contacts_show" -> try {
                app.startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ToolResults.status("done")
            } catch (ignored: Exception) { ToolResults.status("failed") }
            "contact_save" -> contactSave(app, args.optString("name"), args.optString("number"))
            "contact_delete" -> contactDelete(app, args.optString("name"))
            "contact_lookup" -> contactLookup(app, args.optString("name"))

            "set_wifi" -> SystemToggles.quickToggle(app, "wifi", bool(args, "on"))
            "set_bluetooth" -> SystemToggles.quickToggle(app, "bluetooth", bool(args, "on"))
            "airplane_mode" -> SystemToggles.quickToggle(app, "airplane", bool(args, "on"))
            "set_flashlight" -> SystemToggles.flashlight(app, bool(args, "on"))
            "volume_change" -> SystemToggles.volumeChange(app, args.optString("direction"))
            "volume_set" -> SystemToggles.volumeSet(app, args.optString("percent").toDoubleOrNull()?.toInt() ?: 50)
            "mute" -> SystemToggles.mute(app, bool(args, "on"))
            "set_ringer_mode" -> SystemToggles.ringerMode(app, args.optString("mode"))
            "brightness_change" -> SystemToggles.brightnessChange(app, args.optString("direction"))
            "dnd" -> SystemToggles.dnd(app, bool(args, "on"))
            "take_photo" -> takePhoto(app, d, args.optString("camera"))

            "read_recent_notifications" -> NotificationTools.readRecent(app, args.optString("limit").toIntOrNull() ?: 5, args.optString("app").takeIf { it.isNotBlank() })
            "notifications_toggle" -> NotificationTools.toggle(app, bool(args, "on"))
            "notification_reply" -> NotificationTools.reply(app, args.optString("key"), args.optString("text"))

            "screen_share" -> when (args.optString("action").lowercase()) {
                "start" -> ScreenShareController.requestStart(app)
                "stop" -> ToolResults.status("only_user_can_stop", "Tell the user to tap Stop in the notification or the LIVE chip; the assistant cannot stop screen share")
                else -> JSONObject().put("status", if (ScreenShareController.active.value) "sharing" else "off")
            }
            "guide_form" -> FormGuideController.handle(args.optString("action"), args.optString("mode"))
            else -> ToolResults.unknown(name)
        }
    }

    private fun global(d: ScreenDriver, action: Int): JSONObject = ToolResults.status(if (d.globalAction(action)) "done" else "failed")

    private suspend fun openApp(ctx: Context, query: String): JSONObject {
        if (query.isBlank()) return ToolResults.error("app_name missing")
        val hit = AppLauncher.findApp(ctx, query) ?: return ToolResults.status("not_found", "No installed app matches '$query'")
        return if (AppLauncher.launch(ctx, hit.second)) JSONObject().put("status", "opened").put("app", hit.first)
        else ToolResults.status("failed", "Couldn't launch ${hit.first}")
    }

    private fun clickAny(d: ScreenDriver): JSONObject {
        val labels = d.actionableLabels()
        return when {
            labels.isEmpty() -> ToolResults.status("element_not_found")
            labels.size == 1 -> ToolResults.status(if (d.clickText(labels[0])) "tapped" else "failed")
            else -> JSONObject().put("status", "ambiguous").put("options", JSONArray(labels.take(8))).put("reason", "Ask the user which one")
        }
    }

    private suspend fun whatsAppSearch(ctx: Context, d: ScreenDriver, name: String): JSONObject {
        needsA11y()?.let { return it }
        val pkg = CommIntents.whatsAppPackage(ctx) ?: return ToolResults.status("whatsapp_not_installed")
        AppLauncher.launch(ctx, pkg); delay(1800)
        d.clickText("Search"); delay(500)
        return ToolResults.status(if (d.typeText(name)) "done" else "needs_user_tap")
    }

    private suspend fun whatsAppCall(ctx: Context, d: ScreenDriver, name: String, video: Boolean): JSONObject {
        needsA11y()?.let { return it }
        val r = ContactResolver.lookup(ctx, name)
        if (r !is ContactResult.Found) return ToolResults.status(if (r is ContactResult.NoPermission) "needs_contacts_permission" else "contact_not_found")
        if (!CommIntents.openWhatsAppComposer(ctx, r.number, "")) return ToolResults.status("failed")
        delay(2500)
        d.clickText("Continue to chat")
        delay(800)
        return ToolResults.status(if (d.clickText(if (video) "Video call" else "Voice call")) "calling" else "needs_user_tap")
    }

    private fun callContact(ctx: Context, query: String): JSONObject = when (val r = ContactResolver.lookup(ctx, query)) {
        is ContactResult.NoPermission -> ToolResults.status("needs_contacts_permission", "Ask the user to allow Contacts in Permissions")
        is ContactResult.NotFound -> ToolResults.status("contact_not_found")
        is ContactResult.Found -> JSONObject().put("status", CommIntents.call(ctx, r.number)).put("contact", r.name)
    }

    private suspend fun smsSend(ctx: Context, d: ScreenDriver, query: String, text: String): JSONObject {
        val r = ContactResolver.lookup(ctx, query)
        if (r !is ContactResult.Found) return ToolResults.status(if (r is ContactResult.NoPermission) "needs_contacts_permission" else "contact_not_found")
        if (!CommIntents.openSmsComposer(ctx, r.number, text)) return ToolResults.status("failed")
        return JSONObject().put("status", AutoSend.tapSend(d, whatsApp = false)).put("contact", r.name)
    }

    private fun contactSave(ctx: Context, name: String, number: String): JSONObject {
        if (name.isBlank() || number.isBlank()) return ToolResults.error("name and number required")
        ContactStore.save(ctx, name, number)
        if (ctx.checkSelfPermission(android.Manifest.permission.WRITE_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return ToolResults.status("saved_in_app_only", "Allow Contacts write access to save in the phone book too")
        }
        return try {
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI).withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null).withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name).build())
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, number).build())
            ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            ToolResults.status("done")
        } catch (ignored: Exception) { ToolResults.status("saved_in_app_only") }
    }

    private fun contactDelete(ctx: Context, name: String): JSONObject {
        val inApp = ContactStore.delete(ctx, name)
        var phoneBook = false
        if (ctx.checkSelfPermission(android.Manifest.permission.WRITE_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            try {
                ctx.contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.LOOKUP_KEY), "${ContactsContract.Contacts.DISPLAY_NAME} = ?", arrayOf(name.trim()), null)?.use { c ->
                    if (c.moveToFirst()) {
                        val uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, c.getString(0))
                        phoneBook = ctx.contentResolver.delete(uri, null, null) > 0
                    }
                }
            } catch (ignored: Exception) {}
        }
        return ToolResults.status(if (inApp || phoneBook) "done" else "contact_not_found")
    }

    private fun contactLookup(ctx: Context, name: String): JSONObject {
        ContactStore.find(ctx, name)?.let { return JSONObject().put("status", "found").put("name", name).put("number", it) }
        return when (val r = ContactResolver.lookup(ctx, name)) {
            is ContactResult.Found -> JSONObject().put("status", "found").put("name", r.name).put("number", r.number)
            is ContactResult.NoPermission -> ToolResults.status("needs_contacts_permission")
            is ContactResult.NotFound -> ToolResults.status("contact_not_found")
        }
    }

    private suspend fun takePhoto(ctx: Context, d: ScreenDriver, camera: String): JSONObject {
        return try {
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (camera.lowercase() == "front") i.putExtra("android.intent.extras.CAMERA_FACING", 1)
            ctx.startActivity(i)
            if (!d.isAvailable()) return ToolResults.status("needs_user_tap", "Camera is open; tap the shutter button")
            delay(1800)
            val tapped = listOf("Shutter", "Take photo", "Capture").any { d.clickText(it) }
            if (!tapped) return ToolResults.status("needs_user_tap", "Camera is open; tap the shutter button")
            delay(900)
            d.clickText("Done"); d.clickText("OK")
            ToolResults.status("photo_taken")
        } catch (ignored: Exception) { ToolResults.status("failed") }
    }
}
