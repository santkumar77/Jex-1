package com.Jex.assistant.action

/** Abstraction over the screen so logic can be tested with a scripted fake (no device needed). */
interface ScreenDriver {
    fun isAvailable(): Boolean
    fun readScreenLines(maxElements: Int = 40, maxLabelLength: Int = 40): List<String>
    fun clickText(text: String): Boolean
    fun typeText(text: String): Boolean
    fun globalAction(action: Int): Boolean
    suspend fun scroll(direction: String): String
    suspend fun swipe(direction: String): Boolean
    suspend fun tapAt(x: Int, y: Int): Boolean
    fun actionableLabels(): List<String>
    fun currentPackage(): String?
    /** Compact lines with input state, e.g. "[input] Mobile number (empty)". */
    fun readScreenDetailed(): List<String> = readScreenLines(80, 80)
}

object ScreenDrivers {
    @Volatile var current: ScreenDriver = AccessibilityScreenDriver
}

object AccessibilityScreenDriver : ScreenDriver {
    private val svc get() = JexAccessibilityService.instance
    override fun isAvailable() = svc != null
    override fun readScreenLines(maxElements: Int, maxLabelLength: Int) = svc?.readScreen(maxElements, maxLabelLength) ?: emptyList()
    override fun clickText(text: String) = svc?.clickText(text) ?: false
    override fun typeText(text: String) = svc?.typeText(text) ?: false
    override fun globalAction(action: Int) = svc?.performGlobalAction(action) ?: false
    override suspend fun scroll(direction: String) = svc?.scroll(direction) ?: "accessibility_not_enabled"
    override suspend fun swipe(direction: String) = svc?.swipe(direction) ?: false
    override suspend fun tapAt(x: Int, y: Int) = svc?.tapAt(x, y) ?: false
    override fun actionableLabels() = svc?.actionableLabels() ?: emptyList()
    override fun currentPackage() = svc?.rootInActiveWindow?.packageName?.toString()
    override fun readScreenDetailed() = svc?.readScreenDetailed() ?: emptyList()
}
