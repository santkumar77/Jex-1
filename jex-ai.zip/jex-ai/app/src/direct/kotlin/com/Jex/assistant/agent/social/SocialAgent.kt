package com.Jex.assistant.agent.social

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.Jex.assistant.action.ScreenDriver
import com.Jex.assistant.action.ScreenDrivers
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.agent.core.ActionResult
import com.Jex.assistant.agent.core.ScreenObserver
import com.Jex.assistant.agent.core.TextInputExecutor
import com.Jex.assistant.agent.core.TargetResolver
import com.Jex.assistant.agent.core.UiActionExecutor
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class SocialRun(val id: String, val request: SocialTaskRequest) {
    val machine = TaskStateMachine()
    @Volatile var status = TaskStatus.RUNNING
    @Volatile var message = "Starting"
    @Volatile var steps = 0
    @Volatile var gate: CompletableDeferred<ControlCommand>? = null
    fun report() = TaskReport(id, status, message, steps)
}

/** Visual agent for Instagram/Facebook. ALWAYS asks before the irreversible tap. Stops at login/CAPTCHA/2FA. */
object SocialAgent {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val runs = ConcurrentHashMap<String, SocialRun>()

    fun start(ctx: Context, args: JSONObject, driver: ScreenDriver = ScreenDrivers.current): JSONObject {
        if (!driver.isAvailable()) return ToolResults.status("accessibility_not_enabled")
        val req = when (val p = SocialTaskRequest.parse(args)) {
            is SocialTaskRequest.Parsed.Invalid -> return ToolResults.status("invalid_request", p.reason)
            is SocialTaskRequest.Parsed.Ok -> p.request
        }
        if (req.mediaUri != null && !MediaResolver.isShared(req.mediaUri)) {
            return ToolResults.status("media_not_shared", "Ask the user to share the photo or video to Jex AI first")
        }
        val run = SocialRun(UUID.randomUUID().toString().take(8), req)
        runs[run.id] = run
        scope.launch { runTask(ctx.applicationContext, run, driver) }
        return JSONObject().put("status", "started").put("task_id", run.id)
    }

    fun control(command: String, taskId: String?): JSONObject {
        val run = taskId?.let { runs[it] } ?: runs.values.lastOrNull() ?: return ToolResults.status("no_task")
        val cmd = ControlCommand.entries.firstOrNull { it.name.equals(command, true) } ?: return ToolResults.error("unknown command")
        if (cmd == ControlCommand.STATUS) return run.report().toJson()
        if (cmd == ControlCommand.CANCEL) {
            run.gate?.complete(ControlCommand.CANCEL)
            if (!run.machine.state.isTerminal) { run.machine.moveTo(TaskState.CANCELLED); run.status = TaskStatus.CANCELLED; run.message = "Cancelled" }
            return run.report().toJson()
        }
        val g = run.gate ?: return ToolResults.status("nothing_to_confirm", "The task is not waiting for you")
        // CONFIRM is only accepted while the task really waits for confirmation
        if (cmd == ControlCommand.CONFIRM && run.machine.state != TaskState.WAITING_FOR_CONFIRMATION) {
            return ToolResults.status("confirm_refused", "Nothing is waiting for confirmation")
        }
        g.complete(cmd)
        return ToolResults.status("ok")
    }

    private suspend fun await(run: SocialRun): ControlCommand {
        val g = CompletableDeferred<ControlCommand>()
        run.gate = g
        val c = g.await()
        run.gate = null
        return c
    }

    private suspend fun runTask(ctx: Context, run: SocialRun, driver: ScreenDriver) {
        val observer = ScreenObserver(driver)
        val clicker = UiActionExecutor(driver, observer)
        val typer = TextInputExecutor(driver, observer)
        val m = run.machine
        fun fail(msg: String) {
            if (!m.state.isTerminal) m.moveTo(TaskState.FAILED)
            run.status = TaskStatus.FAILED; run.message = msg
        }
        try {
            m.moveTo(TaskState.OPENING_APP)
            val req = run.request
            run.message = "Opening ${req.platform.label}"
            val intent = Intent(Intent.ACTION_SEND).setPackage(req.platform.pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (req.mediaUri != null) {
                val uri = Uri.parse(req.mediaUri)
                intent.setType(if (req.action == SocialAction.CREATE_REEL) "video/*" else "image/*").putExtra(Intent.EXTRA_STREAM, uri)
                ctx.grantUriPermission(req.platform.pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else intent.setType("text/plain")
            if (req.caption.isNotBlank()) intent.putExtra(Intent.EXTRA_TEXT, req.caption)
            try { ctx.startActivity(intent) } catch (ignored: Exception) { fail("${req.platform.label} is not installed or can't take this"); return }
            delay(3000)
            m.moveTo(TaskState.OBSERVING)

            var obs = observer.observe()
            BlockerDetector.detect(obs)?.let { b ->
                m.moveTo(TaskState.WAITING_FOR_USER); run.status = TaskStatus.WAITING_FOR_USER
                run.message = "Blocked by ${b.name.lowercase().replace('_', ' ')}. Please handle it yourself, then say resume."
                if (await(run) != ControlCommand.RESUME) { if (!m.state.isTerminal) { m.moveTo(TaskState.CANCELLED); run.status = TaskStatus.CANCELLED }; return }
                run.status = TaskStatus.RUNNING
                m.moveTo(TaskState.OBSERVING)
                obs = observer.observe()
            }

            // Walk through "Next / Continue" screens (max 3), then reach the publish button.
            var guard = 0
            while (guard++ < 3) {
                val next = Selectors.next.firstOrNull { TargetResolver.resolve(obs, it) != null } ?: break
                m.moveTo(TaskState.RESOLVING_TARGET); m.moveTo(TaskState.VALIDATING_TARGET); m.moveTo(TaskState.EXECUTING_ACTION)
                m.moveTo(TaskState.WAITING_FOR_UI); m.moveTo(TaskState.VERIFYING)
                val r = clicker.click(obs, next)
                run.steps++
                if (r is ActionResult.Failed) { fail("Couldn't tap $next (${r.reason})"); return }
                m.moveTo(TaskState.NEXT_STEP); m.moveTo(TaskState.OBSERVING)
                obs = observer.observe()
            }

            if (req.mode == TaskMode.DRAFT) {
                val draft = Selectors.saveDraft.firstOrNull { TargetResolver.resolve(obs, it) != null }
                if (draft != null) { driver.clickText(draft); run.steps++ }
                m.moveTo(TaskState.COMPLETED); run.status = TaskStatus.COMPLETED
                run.message = if (draft != null) "Saved as a draft. Nothing was published." else "Prepared the post. Nothing was published."
                return
            }

            val publish = Selectors.publish.firstOrNull { TargetResolver.resolve(obs, it) != null }
            if (publish == null) { fail("Couldn't find the publish button"); return }
            m.moveTo(TaskState.RESOLVING_TARGET); m.moveTo(TaskState.VALIDATING_TARGET); m.moveTo(TaskState.WAITING_FOR_CONFIRMATION)
            run.status = TaskStatus.WAITING_FOR_CONFIRMATION
            run.message = "Ready to ${publish.lowercase()} on ${req.platform.label}. Waiting for the user's explicit yes."
            when (await(run)) {
                ControlCommand.CONFIRM -> {}
                else -> { if (!m.state.isTerminal) { m.moveTo(TaskState.CANCELLED); run.status = TaskStatus.CANCELLED; run.message = "Not published" }; return }
            }
            run.status = TaskStatus.RUNNING
            m.moveTo(TaskState.EXECUTING_ACTION); m.moveTo(TaskState.WAITING_FOR_UI); m.moveTo(TaskState.VERIFYING)
            val fresh = observer.observe()
            val clicked = clicker.click(fresh, publish, settleMs = 2500)
            run.steps++
            val after = observer.observe()
            val sawSuccess = listOf("shared", "posted", "your post", "published").any { after.has(it) }
            m.moveTo(TaskState.COMPLETED)
            if (clicked is ActionResult.Failed && !sawSuccess) { run.status = TaskStatus.FAILED; run.message = "The tap didn't go through" }
            else if (sawSuccess) { run.status = TaskStatus.COMPLETED; run.message = "Published." }
            else { run.status = TaskStatus.SUBMITTED_UNVERIFIED; run.message = "I tapped publish but couldn't verify it. Please check ${req.platform.label}." }
        } catch (e: IllegalTransitionException) {
            run.status = TaskStatus.FAILED; run.message = "Internal state error"
        } catch (e: Exception) {
            if (!m.state.isTerminal) m.moveTo(TaskState.FAILED)
            run.status = TaskStatus.FAILED; run.message = "Something went wrong"
        }
    }
}
