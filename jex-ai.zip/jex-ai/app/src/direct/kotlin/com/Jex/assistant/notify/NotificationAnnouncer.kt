package com.Jex.assistant.notify

import android.content.Context
import com.Jex.assistant.data.JexPreferences
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Turns new notifications into ONE short spoken line, queued so Jex is never interrupted mid-sentence. */
object NotificationAnnouncer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val queue = ArrayDeque<NotificationEvent>()
    private var pump: Job? = null

    /** Pure: builds the instruction line sent to the model for one event. */
    fun buildInstruction(e: NotificationEvent, readSensitive: Boolean): String {
        val body = (if (e.messages.isNotEmpty()) e.messages.takeLast(2).joinToString(" / ") else e.text).take(220)
        val sensitive = NotificationRules.isSensitive(body)
        val shown = if (sensitive) {
            if (readSensitive) NotificationRules.maskSensitive(body) else "(hidden: sensitive message, only say that a private message arrived)"
        } else body
        return "[Notification] Read this aloud in ONE short sentence in the user's language, naming the app and sender, then the gist. " +
            "App: ${e.appLabel}. From: ${e.sender.ifBlank { "unknown" }}. Message: $shown. Never read digits of OTPs or passwords."
    }

    fun onEvent(ctx: Context, e: NotificationEvent) {
        val app = ctx.applicationContext
        if (!JexPreferences.getBoolean(app, JexPreferences.Keys.READ_NOTIFICATIONS, false)) return
        if (!VoiceSessionManager.isActive.value) return
        val allow = JexPreferences.getString(app, JexPreferences.Keys.NOTIFICATION_ALLOW_APPS)
        val deny = JexPreferences.getString(app, JexPreferences.Keys.NOTIFICATION_DENY_APPS)
        if (!NotificationRules.appAllowed(e.packageName, allow, deny)) return
        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (nm.currentInterruptionFilter == android.app.NotificationManager.INTERRUPTION_FILTER_NONE) return
        synchronized(queue) { queue.addLast(e) }
        startPump(app)
    }

    private fun startPump(app: Context) {
        if (pump?.isActive == true) return
        pump = scope.launch {
            while (true) {
                val next = synchronized(queue) { if (queue.isEmpty()) null else queue.removeFirst() } ?: break
                // never interrupt Jex mid-sentence
                var waited = 0
                while (VoiceSessionManager.isSpeaking() && waited < 20_000) { delay(300); waited += 300 }
                val sensitiveOk = JexPreferences.getBoolean(app, JexPreferences.Keys.READ_SENSITIVE_ALOUD, false)
                VoiceSessionManager.say(buildInstruction(next, sensitiveOk))
                delay(1500)
            }
        }
    }
}
