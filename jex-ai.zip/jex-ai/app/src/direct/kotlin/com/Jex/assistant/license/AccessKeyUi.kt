package com.Jex.assistant.license

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.components.JexSectionHeader
import com.Jex.assistant.ui.components.JexSettingsRow
import com.Jex.assistant.ui.components.JexTextInputDialog
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.screens.SectionCard
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun AccessKeyBanner(nav: NavHostController) {
    val ctx = LocalContext.current
    val info by AccessKeyManager.info.collectAsState()
    LaunchedEffect(Unit) { AccessKeyManager.refreshInfo(ctx) }
    if (info.active) return
    val c = LocalJexColors.current
    JexGlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), onClick = { nav.navigate(Routes.PROFILE) }) {
        Column(Modifier.padding(16.dp)) {
            Text("Access key needed", style = JexType.title.copy(color = c.warning))
            Text(info.statusText.ifBlank { "Enter your access key in Profile to use Jex AI." }, style = JexType.caption.copy(color = c.textSecondary))
        }
    }
}

@Composable
fun AccessKeySection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val info by AccessKeyManager.info.collectAsState()
    var dialog by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { AccessKeyManager.refreshInfo(ctx) }
    val c = LocalJexColors.current
    JexSectionHeader("Access key")
    SectionCard {
        Column {
            JexSettingsRow(
                Icons.Filled.VpnKey, "Access key",
                subtitle = when {
                    info.active && info.expiresAt > 0 -> "Active until " + DateFormat.getDateInstance().format(Date(info.expiresAt))
                    info.active -> "Active"
                    else -> info.statusText
                },
                value = info.plan.ifBlank { null }, onClick = { dialog = true }
            )
            error?.let { Text(it, style = JexType.caption.copy(color = c.error), modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
        }
    }
    if (dialog) JexTextInputDialog("Enter access key", "", "Key", secret = true, onConfirm = { key ->
        scope.launch { error = AccessKeyManager.activate(ctx, key) }
    }, onDismiss = { dialog = false })
}
