package com.Jex.assistant.ui.fx

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.os.Build
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import com.Jex.assistant.share.ScreenShareController
import com.Jex.assistant.voice.JexOrbState
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * System-wide listening glow (TYPE_APPLICATION_OVERLAY, never touchable). Needs "Display over other apps".
 * While screen share is live it turns teal and shows a LIVE chip so sharing is always obvious.
 */
object OverlayEdgeGlowController {
    private var view: GlowView? = null
    private var job: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    fun canDraw(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun start(ctx: Context) {
        val app = ctx.applicationContext
        if (view != null || !canDraw(app)) return
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = GlowView(app)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(v, lp) } catch (ignored: Exception) { return }
        view = v
        job = scope.launch {
            combine(VoiceSessionManager.state, ScreenShareController.active) { s, share -> s to share }.collect { (s, share) ->
                v.apply(s, share)
            }
        }
    }

    fun stop(ctx: Context) {
        job?.cancel(); job = null
        val v = view ?: return
        view = null
        try { (ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (ignored: Exception) {}
        v.shutdown()
    }

    private class GlowView(ctx: Context) : View(ctx) {
        private var color = Color.parseColor("#8B5CF6")
        private var live = false
        private var alphaF = 0.7f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val chip = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 34f; isFakeBoldText = true }
        private val anim = ValueAnimator.ofFloat(0.5f, 1f).apply {
            duration = 1600; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { alphaF = it.animatedValue as Float; invalidate() }
            start()
        }

        fun apply(state: JexOrbState, share: Boolean) {
            live = share
            color = when {
                share -> Color.parseColor("#3FE0D0")
                state == JexOrbState.SPEAKING -> Color.parseColor("#FF6FAE")
                state == JexOrbState.ERROR -> Color.parseColor("#FF7A85")
                else -> Color.parseColor("#8B5CF6")
            }
            visibility = if (state == JexOrbState.IDLE && !share) GONE else VISIBLE
            invalidate()
        }

        fun shutdown() { anim.cancel() }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat(); val e = 26f * resources.displayMetrics.density
            val a = (255 * 0.85f * alphaF).toInt()
            val c0 = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)); val c1 = Color.TRANSPARENT
            fun grad(x0: Float, y0: Float, x1: Float, y1: Float, l: Float, t: Float, r: Float, b: Float) {
                paint.shader = LinearGradient(x0, y0, x1, y1, c0, c1, Shader.TileMode.CLAMP); c.drawRect(l, t, r, b, paint)
            }
            grad(0f, 0f, 0f, e, 0f, 0f, w, e)
            grad(0f, h, 0f, h - e, 0f, h - e, w, h)
            grad(0f, 0f, e, 0f, 0f, 0f, e, h)
            grad(w, 0f, w - e, 0f, w - e, 0f, w, h)
            if (live) { chip.color = color; c.drawText("● LIVE", w - 170f, e + 40f, chip) }
        }
    }
}
