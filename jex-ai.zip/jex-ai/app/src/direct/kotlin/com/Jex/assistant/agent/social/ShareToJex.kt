package com.Jex.assistant.agent.social

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class JexShareFileProvider : FileProvider()

/**
 * Receives a photo/video the user shares to Jex AI ("Share > Jex AI"), copies it into private storage and
 * registers its content:// URI. These are the ONLY media URIs the social agent will ever use.
 */
class ShareToJexActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val src: Uri? = if (intent?.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)
        } else null
        if (src == null) { finish(); return }
        try {
            val dir = File(filesDir, "SharedMedia").apply { mkdirs() }
            val ext = if ((intent.type ?: "").startsWith("video")) "mp4" else "jpg"
            val dest = File(dir, "shared_${System.currentTimeMillis()}.$ext")
            contentResolver.openInputStream(src)?.use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
            val uri = FileProvider.getUriForFile(this, "$packageName.share.fileprovider", dest)
            MediaResolver.register(uri.toString())
            Toast.makeText(this, "Saved for Jex AI. Now tell Jex what to post.", Toast.LENGTH_LONG).show()
        } catch (ignored: Exception) {
            Toast.makeText(this, "Couldn't read that file.", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
