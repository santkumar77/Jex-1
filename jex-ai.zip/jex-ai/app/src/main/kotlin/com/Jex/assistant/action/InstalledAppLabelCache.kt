package com.Jex.assistant.action

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Process-wide map lowercase label -> package for launchable apps. Built once on IO, 15 minute TTL. */
object InstalledAppLabelCache {
    private const val TTL_MS = 15 * 60 * 1000L
    private val mutex = Mutex()
    @Volatile private var map: Map<String, String> = emptyMap()
    @Volatile private var builtAt = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun prewarm(ctx: Context) {
        val app = ctx.applicationContext
        scope.launch { get(app) }
    }

    suspend fun get(ctx: Context): Map<String, String> {
        val now = SystemClock.elapsedRealtime()
        if (map.isNotEmpty() && now - builtAt < TTL_MS) return map
        return mutex.withLock {
            val n = SystemClock.elapsedRealtime()
            if (map.isNotEmpty() && n - builtAt < TTL_MS) return@withLock map
            val pm = ctx.applicationContext.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val result = LinkedHashMap<String, String>()
            try {
                for (ri in pm.queryIntentActivities(intent, 0)) {
                    val label = ri.loadLabel(pm)?.toString()?.trim()?.lowercase().orEmpty()
                    if (label.isNotEmpty()) result.putIfAbsent(label, ri.activityInfo.packageName)
                }
            } catch (ignored: Exception) {
            }
            map = result
            builtAt = SystemClock.elapsedRealtime()
            map
        }
    }

    fun invalidate() { builtAt = 0L }
}
