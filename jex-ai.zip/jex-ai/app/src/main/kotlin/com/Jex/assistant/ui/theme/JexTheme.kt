package com.Jex.assistant.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.Jex.assistant.data.ThemeMode

@Composable
fun JexTheme(
    mode: ThemeMode = ThemeMode.DARK,
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val c = if (dark) JexColorScheme.Dark else JexColorScheme.Light
    val material = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent, secondary = c.accentSecondary, background = c.background,
            onBackground = c.textPrimary, surface = c.surface, onSurface = c.textPrimary, error = c.error,
            surfaceVariant = c.surfaceRaised, onSurfaceVariant = c.textSecondary, outline = c.surfaceBorder
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent, secondary = c.accentSecondary, background = c.background,
            onBackground = c.textPrimary, surface = c.surface, onSurface = c.textPrimary, error = c.error,
            surfaceVariant = c.surfaceRaised, onSurfaceVariant = c.textSecondary, outline = c.surfaceBorder
        )
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = android.graphics.Color.TRANSPARENT
                window.navigationBarColor = android.graphics.Color.TRANSPARENT
                val ctl = WindowCompat.getInsetsController(window, view)
                ctl.isAppearanceLightStatusBars = !dark
                ctl.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalJexColors provides c, LocalJexReducedMotion provides reducedMotion) {
        MaterialTheme(colorScheme = material, typography = JexTypography, content = content)
    }
}
