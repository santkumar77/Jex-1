package com.Jex.assistant.ui.nav

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Jex.assistant.ui.fx.JexOrb3D
import com.Jex.assistant.ui.fx.JexOrbStyle
import com.Jex.assistant.ui.theme.JexShapes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.MinTouchTarget
import com.Jex.assistant.ui.theme.depthSurface
import com.Jex.assistant.voice.VoiceSessionManager

@Composable
fun JexBottomNavigation(currentRoute: String?, onNavigate: (String) -> Unit, orbStyle: JexOrbStyle, modifier: Modifier = Modifier) {
    val c = LocalJexColors.current
    val state by VoiceSessionManager.state.collectAsState()
    val amp by VoiceSessionManager.amplitude.collectAsState()
    Box(modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 64.dp).depthSurface(c, JexShapes.pill, 10.dp, c.surfaceGlass),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem("Home", Icons.Filled.Home, currentRoute == Routes.HOME) { onNavigate(Routes.HOME) }
            NavItem("Chat", Icons.Filled.ChatBubble, currentRoute == Routes.CHAT) { onNavigate(Routes.CHAT) }
            Box(Modifier.width(72.dp))
            NavItem("History", Icons.Filled.History, currentRoute == Routes.HISTORY) { onNavigate(Routes.HISTORY) }
            NavItem("Settings", Icons.Filled.Settings, currentRoute == Routes.SETTINGS) { onNavigate(Routes.SETTINGS) }
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-16).dp).size(76.dp)
                .semantics { contentDescription = "Talk" }
                .clickable { onNavigate(Routes.VOICE) },
            contentAlignment = Alignment.Center
        ) { JexOrb3D(state, 76.dp, amp, style = orbStyle) }
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val c = LocalJexColors.current
    Column(
        Modifier.heightIn(min = MinTouchTarget).width(60.dp).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (selected) c.accent else c.textSecondary)
        Text(label, style = JexType.caption.copy(color = if (selected) c.accent else c.textSecondary))
    }
}
