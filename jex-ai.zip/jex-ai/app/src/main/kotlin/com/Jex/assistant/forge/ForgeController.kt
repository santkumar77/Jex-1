package com.Jex.assistant.forge

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.core.app.NotificationCompat
import com.Jex.assistant.MainActivity
import com.Jex.assistant.R
import com.Jex.assistant.data.ApiKeyStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

/** Process-wide Forge controller: a build survives leaving the screen, rotating or backgrounding. */
object ForgeController {
    const val EXTRA_OPEN_FORGE = "com.Jex.assistant.extra.OPEN_FORGE"
    private const val CHANNEL = "jex_forge_ready"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(ForgeUiState())
    val state: StateFlow<ForgeUiState> = _state

    private val _pendingOpen = MutableStateFlow(false)
    val pendingOpen: StateFlow<Boolean> = _pendingOpen

    @Volatile var screenVisible = false
    private var job: Job? = null
    private val partial = StringBuilder()
    private var lastPrompt = ""
    private var lastIsEdit = false
    private var lastEditChange = ""
    private var currentHtmlForEdit: String? = null

    fun partialHtml(): String = synchronized(partial) { partial.toString() }

    fun requestOpen() { _pendingOpen.value = true }
    fun consumePendingOpen() { _pendingOpen.value = false }

    fun websitesDir(ctx: Context): File = File(ctx.applicationContext.filesDir, "Websites").also { it.mkdirs() }

    fun listSaved(ctx: Context): List<File> =
        websitesDir(ctx).listFiles { f -> f.extension == "html" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun start(ctx: Context, prompt: String): ForgeStartResult {
        val app = ctx.applicationContext
        if (_state.value.phase == ForgePhase.BUILDING) return ForgeStartResult.Busy
        if (!ApiKeyStore.hasKey(app)) return ForgeStartResult.MissingKey
        if (!isOnline(app)) return ForgeStartResult.Offline
        lastPrompt = prompt.ifBlank { "A beautiful modern website" }
        lastIsEdit = false
        currentHtmlForEdit = null
        launchBuild(app, lastPrompt, isEdit = false, editChange = "", currentHtml = null)
        requestOpen()
        return ForgeStartResult.Started
    }

    fun edit(ctx: Context, change: String): ForgeStartResult {
        val app = ctx.applicationContext
        if (_state.value.phase == ForgePhase.BUILDING) return ForgeStartResult.Busy
        val file = _state.value.file ?: listSaved(app).firstOrNull() ?: return ForgeStartResult.NothingToEdit
        if (!ApiKeyStore.hasKey(app)) return ForgeStartResult.MissingKey
        if (!isOnline(app)) return ForgeStartResult.Offline
        val html = try { file.readText() } catch (ignored: Exception) { return ForgeStartResult.NothingToEdit }
        lastIsEdit = true
        lastEditChange = change
        currentHtmlForEdit = html
        launchBuild(app, _state.value.prompt.ifBlank { lastPrompt }, isEdit = true, editChange = change, currentHtml = html)
        requestOpen()
        return ForgeStartResult.Started
    }

    fun retry(ctx: Context): ForgeStartResult {
        val app = ctx.applicationContext
        if (_state.value.phase == ForgePhase.BUILDING) return ForgeStartResult.Busy
        if (!ApiKeyStore.hasKey(app)) return ForgeStartResult.MissingKey
        if (!isOnline(app)) return ForgeStartResult.Offline
        if (lastPrompt.isBlank() && !lastIsEdit) return ForgeStartResult.NothingToEdit
        launchBuild(app, lastPrompt, lastIsEdit, lastEditChange, currentHtmlForEdit)
        return ForgeStartResult.Started
    }

    fun cancel() {
        job?.cancel()
        job = null
        if (_state.value.phase == ForgePhase.BUILDING) {
            _state.value = _state.value.copy(phase = ForgePhase.CANCELLED, error = null)
        }
    }

    fun reset() {
        job?.cancel()
        synchronized(partial) { partial.setLength(0) }
        _state.value = ForgeUiState()
    }

    fun openSaved(file: File) {
        val html = try { file.readText() } catch (ignored: Exception) { return }
        synchronized(partial) { partial.setLength(0); partial.append(html) }
        _state.value = ForgeUiState(
            phase = ForgePhase.DONE, prompt = file.nameWithoutExtension, stage = ForgeStage.READY, progress = 1f,
            sections = ForgeSections.extract(html), buildId = System.currentTimeMillis(), file = file
        )
        requestOpen()
    }

    // ---------------------------------------------------------------------------------------------

    private fun launchBuild(app: Context, prompt: String, isEdit: Boolean, editChange: String, currentHtml: String?) {
        job?.cancel()
        val buildId = System.currentTimeMillis()
        synchronized(partial) { partial.setLength(0) }
        _state.value = ForgeUiState(
            phase = ForgePhase.BUILDING, prompt = prompt, isEdit = isEdit, stage = ForgeStage.READING,
            buildId = buildId, log = listOf(ForgeStage.READING.label), logSeq = 1
        )
        job = scope.launch {
            try {
                runBuild(app, buildId, prompt, isEdit, editChange, currentHtml)
            } catch (ignored: CancellationException) {
                // cancel() already set the state
            } catch (e: Exception) {
                fail(buildId, "Something went wrong while building. Please try again.")
            }
        }
    }

    private suspend fun runBuild(app: Context, buildId: Long, prompt: String, isEdit: Boolean, editChange: String, currentHtml: String?) {
        val key = ApiKeyStore.getKey(app)
        val model = WebsiteForgeClient.resolveModel(key)
        if (model == null) { fail(buildId, "Couldn't find a Gemini model. Check your API key and internet."); return }

        val system = if (isEdit && currentHtml != null) ForgeSystemPrompt.forEdit(currentHtml, editChange) else ForgeSystemPrompt.forNewSite(prompt)
        val userText = if (isEdit) "Apply the requested change and return the full HTML file." else prompt

        val startMs = System.currentTimeMillis()
        var lastEmit = 0L
        var lastLoggedKb = 0
        var lastStage = ForgeStage.READING
        var seenSections = 0
        var progress = 0f
        var logSeq = 1
        val log = ArrayList<String>().apply { add(ForgeStage.READING.label) }

        fun emit(force: Boolean) {
            val now = System.currentTimeMillis()
            if (!force && now - lastEmit < 120) return
            lastEmit = now
            val html = partialHtml()
            val stage = ForgeStageDetector.detect(html)
            if (stage.ordinal > lastStage.ordinal) {
                lastStage = stage; log.add(stage.label); logSeq++
            }
            val sections = ForgeSections.extract(html)
            while (seenSections < sections.size) {
                log.add("Laying out ${sections[seenSections]}"); seenSections++; logSeq++
            }
            val kb = html.length / 10_000
            if (kb > lastLoggedKb) { lastLoggedKb = kb; log.add("${kb * 10} KB written"); logSeq++ }
            progress = maxOf(progress, ForgeStageDetector.progress(stage, html.length))
            val elapsed = ((now - startMs) / 1000).toInt().coerceAtLeast(1)
            val tps = (html.length / 4) / elapsed
            val cur = _state.value
            if (cur.buildId != buildId || cur.phase != ForgePhase.BUILDING) return
            _state.value = cur.copy(
                stage = stage, progress = progress,
                metrics = ForgeMetrics(html.length, sections.size, elapsed, tps),
                sections = sections, log = log.takeLast(6).toList(), logSeq = logSeq
            )
        }

        var hint: String? = null
        var attempt = 0
        var overloadedRetried = false
        var finalHtml: String? = null
        while (attempt < 3) {
            attempt++
            synchronized(partial) { partial.setLength(0) }
            val result = WebsiteForgeClient.stream(
                key, model, system + (hint?.let { "\n\n$it" } ?: ""), userText
            ) { delta ->
                synchronized(partial) { partial.append(delta) }
                emit(false)
            }
            emit(true)
            if (result.error != null && partialHtml().length < 200) {
                if (result.overloaded && !overloadedRetried) {
                    overloadedRetried = true
                    attempt--
                    delay(4000)
                    continue
                }
                fail(buildId, WebsiteForgeClient.friendlyError(result))
                return
            }
            val cleaned = ForgeHtml.stripFences(partialHtml())
            val complete = cleaned.length >= 1500 && cleaned.contains("</html>", ignoreCase = true)
            if (complete) { finalHtml = cleaned; break }
            if (hint == null) { hint = ForgeSystemPrompt.RETRY_HINT; continue }
            if (cleaned.length >= 14_000 && ForgeHtml.looksLikeHtml(cleaned)) {
                finalHtml = ForgeHtml.repairTruncated(cleaned); break
            }
            fail(buildId, "Gemini stopped before finishing the page. Please try again.")
            return
        }
        val html = finalHtml ?: run { fail(buildId, "Gemini stopped before finishing the page. Please try again."); return }
        val safe = ForgeHtml.withSafetyNet(html)
        val file = File(websitesDir(app), "website_${System.currentTimeMillis()}.html")
        file.writeText(safe)
        synchronized(partial) { partial.setLength(0); partial.append(safe) }
        val cur = _state.value
        if (cur.buildId != buildId || cur.phase != ForgePhase.BUILDING) return
        _state.value = cur.copy(
            phase = ForgePhase.DONE, stage = ForgeStage.READY, progress = 1f, file = file, error = null,
            sections = ForgeSections.extract(safe),
            log = (log + "Ready").takeLast(6), logSeq = logSeq + 1
        )
        if (!screenVisible) notifyReady(app)
    }

    private fun fail(buildId: Long, message: String) {
        val cur = _state.value
        if (cur.buildId != buildId) return
        _state.value = cur.copy(phase = ForgePhase.FAILED, error = message)
    }

    private fun notifyReady(app: Context) {
        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Website ready", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val pi = PendingIntent.getActivity(
            app, 7,
            Intent(app, MainActivity::class.java).putExtra(EXTRA_OPEN_FORGE, true).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(app, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jex)
            .setContentTitle("Your website is ready")
            .setContentText("Tap to open it")
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try { nm.notify(7001, n) } catch (ignored: SecurityException) {}
    }
}
