package com.Jex.assistant.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Jex.assistant.data.ChatMessage
import com.Jex.assistant.ui.theme.JexShapes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.LocalJexReducedMotion
import com.Jex.assistant.ui.theme.MinTouchTarget
import com.Jex.assistant.ui.theme.depthSurface
import kotlin.math.sin

@Composable
fun JexGlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    elevation: androidx.compose.ui.unit.Dp = 6.dp,
    content: @Composable () -> Unit
) {
    val c = LocalJexColors.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val reduced = LocalJexReducedMotion.current
    val scale = if (pressed && !reduced) 0.97f else 1f
    var m = modifier.scale(scale).depthSurface(c, JexShapes.medium, if (pressed) elevation / 2 else elevation)
    if (onClick != null) m = m.clip(JexShapes.medium).clickable(interactionSource = src, indication = null, onClick = onClick)
    Box(m) { content() }
}

enum class JexButtonStyle { PRIMARY, SECONDARY, TEXT }

@Composable
fun JexButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: JexButtonStyle = JexButtonStyle.PRIMARY,
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    val c = LocalJexColors.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val reduced = LocalJexReducedMotion.current
    val haptic = LocalHapticFeedback.current
    val bg = when (style) {
        JexButtonStyle.PRIMARY -> c.accent
        JexButtonStyle.SECONDARY -> c.surfaceGlass
        JexButtonStyle.TEXT -> Color.Transparent
    }
    val fg = when (style) {
        JexButtonStyle.PRIMARY -> c.onAccent
        else -> c.textPrimary
    }
    Row(
        modifier
            .scale(if (pressed && !reduced) 0.96f else 1f)
            .alpha(if (enabled) 1f else 0.5f)
            .heightIn(min = MinTouchTarget)
            .clip(JexShapes.pill)
            .background(bg, JexShapes.pill)
            .clickable(interactionSource = src, indication = null, enabled = enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 22.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = JexType.label.copy(color = fg))
    }
}

@Composable
fun JexTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    secret: Boolean = false,
    singleLine: Boolean = true,
    imeAction: ImeAction = ImeAction.Done,
    onImeAction: (() -> Unit)? = null
) {
    val c = LocalJexColors.current
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = singleLine,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(imeAction = imeAction),
        keyboardActions = KeyboardActions(onAny = { onImeAction?.invoke() }),
        shape = JexShapes.small,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = c.accent, unfocusedBorderColor = c.surfaceBorder,
            focusedTextColor = c.textPrimary, unfocusedTextColor = c.textPrimary,
            focusedLabelColor = c.accent, unfocusedLabelColor = c.textSecondary, cursorColor = c.accent
        ),
        modifier = modifier.fillMaxWidth().heightIn(min = MinTouchTarget)
    )
}

@Composable
fun JexTopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable () -> Unit = {}) {
    val c = LocalJexColors.current
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.size(MinTouchTarget)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.textPrimary)
            }
        } else Spacer(Modifier.width(12.dp))
        Text(title, style = JexType.headline.copy(color = c.textPrimary, fontSize = 24.sp), modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun JexSectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = JexType.caption.copy(color = LocalJexColors.current.accent),
        modifier = modifier.padding(start = 20.dp, top = 20.dp, bottom = 6.dp)
    )
}

@Composable
fun JexSettingsRow(
    icon: ImageVector,
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    value: String? = null,
    switchValue: Boolean? = null,
    onSwitch: ((Boolean) -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    val c = LocalJexColors.current
    val rowMod = modifier.fillMaxWidth().heightIn(min = 56.dp).let {
        when {
            onClick != null -> it.clickable(onClick = onClick)
            switchValue != null && onSwitch != null -> it.clickable { onSwitch(!switchValue) }
            else -> it
        }
    }.padding(horizontal = 16.dp, vertical = 8.dp)
    Row(rowMod, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(36.dp).background(c.accentGlow, CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = c.accent, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = JexType.title.copy(color = c.textPrimary))
            if (subtitle != null) Text(subtitle, style = JexType.caption.copy(color = c.textSecondary))
        }
        if (value != null) Text(value, style = JexType.label.copy(color = c.textSecondary))
        if (switchValue != null && onSwitch != null) {
            Switch(
                checked = switchValue, onCheckedChange = onSwitch,
                colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = c.onAccent)
            )
        } else if (onClick != null) {
            Icon(Icons.Filled.ChevronRight, null, tint = c.textTertiary)
        }
    }
}

@Composable
fun JexMessageBubble(
    message: ChatMessage,
    modifier: Modifier = Modifier,
    actions: @Composable () -> Unit = {}
) {
    val c = LocalJexColors.current
    val align = if (message.isUser) Alignment.End else Alignment.Start
    val bg = when {
        message.isError -> c.error.copy(alpha = 0.18f)
        message.isUser -> c.userBubble
        else -> c.assistantBubble
    }
    Column(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalAlignment = align) {
        Box(
            Modifier.widthIn(max = 300.dp).depthSurface(c, JexShapes.medium, 4.dp, bg).padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            if (message.isStreaming && message.text.isBlank()) JexTypingDots()
            else Text(message.text, style = JexType.body.copy(color = if (message.isError) c.error else c.textPrimary))
        }
        if (!message.isUser && !message.isStreaming) Row { actions() }
    }
}

@Composable
fun JexTypingDots(modifier: Modifier = Modifier) {
    val c = LocalJexColors.current
    val reduced = LocalJexReducedMotion.current
    val t = rememberInfiniteTransition(label = "dots")
    val phase by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1200), RepeatMode.Restart), label = "p")
    Row(modifier.semantics { contentDescription = "Typing" }, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        for (i in 0 until 3) {
            val a = if (reduced) 0.7f else 0.35f + 0.65f * ((sin(phase - i * 0.9f) + 1f) / 2f)
            Box(Modifier.size(8.dp).alpha(a).background(c.textSecondary, CircleShape))
        }
    }
}

/** 48 bars around the orb scaled by amplitude (speaking only). */
@Composable
fun JexVoiceVisualizer(amplitude: Float, active: Boolean, modifier: Modifier = Modifier) {
    val c = LocalJexColors.current
    val reduced = LocalJexReducedMotion.current
    val t = rememberInfiniteTransition(label = "viz")
    val phase by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1600), RepeatMode.Restart), label = "vp")
    androidx.compose.foundation.Canvas(modifier) {
        if (!active) return@Canvas
        val r = size.minDimension / 2f * 0.78f
        val cx = size.width / 2f
        val cy = size.height / 2f
        val bars = 48
        for (i in 0 until bars) {
            val ang = (i / bars.toFloat()) * 6.2832f
            val wob = if (reduced) 0.5f else 0.5f + 0.5f * sin(phase * 2f + i * 0.7f)
            val len = (6f + amplitude.coerceIn(0f, 1f) * 46f * wob) * density
            val x0 = cx + kotlin.math.cos(ang) * r
            val y0 = cy + kotlin.math.sin(ang) * r
            val x1 = cx + kotlin.math.cos(ang) * (r + len)
            val y1 = cy + kotlin.math.sin(ang) * (r + len)
            drawLine(c.accent.copy(alpha = 0.85f), androidx.compose.ui.geometry.Offset(x0, y0), androidx.compose.ui.geometry.Offset(x1, y1), strokeWidth = 3f * density)
        }
    }
}

@Composable
fun JexEmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    buttonText: String? = null,
    onButton: (() -> Unit)? = null,
    visual: @Composable () -> Unit = {}
) {
    val c = LocalJexColors.current
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        visual()
        Spacer(Modifier.height(16.dp))
        Text(title, style = JexType.headline.copy(color = c.textPrimary), textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(message, style = JexType.body.copy(color = c.textSecondary), textAlign = TextAlign.Center)
        if (buttonText != null && onButton != null) {
            Spacer(Modifier.height(20.dp))
            JexButton(buttonText, onButton)
        }
    }
}

@Composable
fun JexConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalJexColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surfaceRaised,
        title = { Text(title, style = JexType.title.copy(color = c.textPrimary)) },
        text = { Text(message, style = JexType.body.copy(color = c.textSecondary)) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmText, color = c.accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.textSecondary) } }
    )
}

@Composable
fun <T> JexChoiceDialog(
    title: String,
    options: List<T>,
    label: (T) -> String,
    selected: T,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalJexColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surfaceRaised,
        title = { Text(title, style = JexType.title.copy(color = c.textPrimary)) },
        text = {
            Column {
                options.forEach { o ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = MinTouchTarget)
                            .clickable { onSelect(o); onDismiss() }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            (if (o == selected) "●  " else "○  ") + label(o),
                            style = JexType.body.copy(color = if (o == selected) c.accent else c.textPrimary)
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = c.accent) } }
    )
}

@Composable
fun JexTextInputDialog(
    title: String,
    initial: String,
    label: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    secret: Boolean = false
) {
    val c = LocalJexColors.current
    var text by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surfaceRaised,
        title = { Text(title, style = JexType.title.copy(color = c.textPrimary)) },
        text = { JexTextField(text, { text = it }, label, secret = secret) },
        confirmButton = { TextButton(onClick = { onConfirm(text); onDismiss() }) { Text("Save", color = c.accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.textSecondary) } }
    )
}
