package com.Jex.assistant

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.forge.ForgeController
import com.Jex.assistant.license.AccessKeyManager
import com.Jex.assistant.ui.fx.ListeningEdgeGlow
import com.Jex.assistant.ui.nav.JexApp
import com.Jex.assistant.ui.screens.splash.JexSplash3D
import com.Jex.assistant.ui.screens.splash.SplashSession
import com.Jex.assistant.ui.theme.JexTheme
import com.Jex.assistant.voice.JexOrbState
import com.Jex.assistant.voice.VoiceForegroundService
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {
    private lateinit var appState: JexAppState

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        appState = JexAppState(this)
        handleIntent(intent)
        setContent {
            JexTheme(appState.themeMode, appState.reducedMotion) {
                var splashDone by remember { mutableStateOf(SplashSession.played) }
                Box {
                    JexApp(appState)
                    if (!splashDone) JexSplash3D { splashDone = true }
                    EdgeGlowHost()
                    LicenseWatcher()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(ForgeController.EXTRA_OPEN_FORGE, false) == true) {
            ForgeController.requestOpen()
            intent.removeExtra(ForgeController.EXTRA_OPEN_FORGE)
        }
    }

    /** Full-screen, non-touchable Dialog window hosting the listening glow above every screen. */
    @Composable
    private fun EdgeGlowHost() {
        val active by VoiceSessionManager.isActive.collectAsState()
        val state by VoiceSessionManager.state.collectAsState()
        if (!active || state == JexOrbState.IDLE) return
        Dialog(
            onDismissRequest = {},
            properties = DialogProperties(
                dismissOnBackPress = false, dismissOnClickOutside = false,
                usePlatformDefaultWidth = false, decorFitsSystemWindows = false
            )
        ) {
            val window = (LocalView.current.parent as? DialogWindowProvider)?.window
            SideEffect {
                window?.apply {
                    setDimAmount(0f)
                    setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
                    addFlags(
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    )
                }
            }
            ListeningEdgeGlow(state)
        }
    }

    /** Re-runs the licence check on resume (direct flavor) and stops a running session if the key got blocked. */
    @Composable
    private fun LicenseWatcher() {
        val ctx = LocalContext.current
        val owner = LocalLifecycleOwner.current
        DisposableEffect(owner) {
            val obs = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    lifecycleScope.launch {
                        AccessKeyManager.liveCheck(ctx)
                        if (!AccessKeyManager.isActive(ctx) && VoiceSessionManager.isActive.value) {
                            VoiceForegroundService.stop(ctx)
                        }
                    }
                }
            }
            owner.lifecycle.addObserver(obs)
            onDispose { owner.lifecycle.removeObserver(obs) }
        }
    }
}
