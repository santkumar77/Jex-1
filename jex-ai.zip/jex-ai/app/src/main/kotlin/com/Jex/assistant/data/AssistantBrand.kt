package com.Jex.assistant.data

/** Single source of truth for the assistant's identity (Part 02 + Part 17). */
object AssistantBrand {
    const val NAME = "Jex"
    const val FULL_NAME = "Jex AI"
    const val TAGLINE = "Your Intelligent AI Companion"
    const val DEVELOPER = "जसवंत डेहरिया"
    const val DEVELOPER_LATIN = "Jaswant Dehariya"
    const val CREDIT_LINE = "Made by जसवंत डेहरिया"
}
