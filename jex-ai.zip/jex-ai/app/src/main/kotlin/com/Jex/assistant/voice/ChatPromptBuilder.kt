package com.Jex.assistant.voice

import com.Jex.assistant.data.LanguagePreference
import com.Jex.assistant.data.Personality

object ChatPromptBuilder {
    fun build(personality: Personality, language: LanguagePreference, assistantName: String): String = listOf(
        "You are $assistantName, a persistent personal assistant living on the user's phone. Keep replies concise and helpful.\n" +
            IdentityPrompt.build(),
        "This is typed chat. Never mention tapping, listening or speaking, and never say you can hear the user.",
        personality.systemInstruction,
        PersonalityPromptBuilder.languagePolicy(language, DetectedLanguage.UNKNOWN),
        PersonalityPromptBuilder.SAFETY
    ).joinToString("\n\n")
}
