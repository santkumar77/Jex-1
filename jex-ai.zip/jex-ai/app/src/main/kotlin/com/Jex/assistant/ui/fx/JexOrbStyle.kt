package com.Jex.assistant.ui.fx

enum class JexOrbStyle(val displayName: String) {
    JEX("Jex"), AURORA("Aurora"), PLASMA("Plasma"), GLASS("Glass"), ENERGY("Energy"), MINIMAL("Minimal"), ARCHER("Particles");

    companion object {
        fun fromName(name: String?): JexOrbStyle = entries.firstOrNull { it.name == name } ?: JEX
    }
}
