package com.Jex.assistant.ui.fx

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.graphics.Color
import com.Jex.assistant.voice.JexOrbState

data class OrbColors(val core: Color, val rim: Color, val halo: Color)

object OrbPalette {
    private val Lotus = Color(0xFFFF6FAE)
    private val Violet = Color(0xFF8B5CF6)
    private val Lagoon = Color(0xFF3FE0D0)
    private val Marigold = Color(0xFFFFB547)
    private val Amber = Color(0xFFFFA726)
    private val Red = Color(0xFFFF7A85)

    fun forState(state: JexOrbState): OrbColors = when (state) {
        JexOrbState.IDLE -> OrbColors(Violet, Lotus, Violet)
        JexOrbState.LISTENING -> OrbColors(Lagoon, Color(0xFFB8FFF6), Lagoon)
        JexOrbState.THINKING -> OrbColors(Color(0xFF7C4DFF), Lotus, Violet)
        JexOrbState.SPEAKING -> OrbColors(Marigold, Lotus, Color(0xFFFF8A3D))
        JexOrbState.CONNECTING -> OrbColors(Amber, Color(0xFFFFE0A3), Amber)
        JexOrbState.ERROR -> OrbColors(Color(0xFF8A2E3A), Red, Red)
    }

    fun forStyle(style: JexOrbStyle, base: OrbColors): OrbColors = when (style) {
        JexOrbStyle.JEX, JexOrbStyle.ARCHER -> base
        JexOrbStyle.AURORA -> base.copy(rim = Lagoon)
        JexOrbStyle.PLASMA -> base.copy(core = Lotus, rim = Violet)
        JexOrbStyle.GLASS -> base.copy(rim = Color.White)
        JexOrbStyle.ENERGY -> base.copy(core = Marigold, rim = Amber)
        JexOrbStyle.MINIMAL -> base.copy(rim = base.core)
    }
}

@Composable
fun animatedOrbColors(state: JexOrbState, style: JexOrbStyle = JexOrbStyle.JEX): Triple<State<Color>, State<Color>, State<Color>> {
    val c = OrbPalette.forStyle(style, OrbPalette.forState(state))
    val spec = tween<Color>(500)
    return Triple(
        animateColorAsState(c.core, spec, label = "core"),
        animateColorAsState(c.rim, spec, label = "rim"),
        animateColorAsState(c.halo, spec, label = "halo")
    )
}
