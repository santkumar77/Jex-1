package com.Jex.assistant.voice

/** Rolling window of the last 12 turns, in memory only; cleared when the session stops. */
class ConversationMemory(private val maxTurns: Int = 12) {
    enum class Role { USER, ASSISTANT }
    data class Turn(val role: Role, val text: String)

    private val lock = Any()
    private val turns = ArrayDeque<Turn>()

    fun add(role: Role, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        synchronized(lock) {
            // merge consecutive fragments of the same speaker into one turn
            val last = turns.lastOrNull()
            if (last != null && last.role == role && last.text.length < 600) {
                turns.removeLast()
                turns.addLast(Turn(role, last.text + " " + clean))
            } else {
                turns.addLast(Turn(role, clean))
            }
            while (turns.size > maxTurns) turns.removeFirst()
        }
    }

    fun isEmpty(): Boolean = synchronized(lock) { turns.isEmpty() }

    fun clear() = synchronized(lock) { turns.clear() }

    /** "User: ..." / "You: ..." lines, capped to the last 1600 chars. Null when empty. */
    fun recap(): String? {
        val text = synchronized(lock) {
            turns.joinToString("\n") { (if (it.role == Role.USER) "User: " else "You: ") + it.text }
        }
        if (text.isBlank()) return null
        return if (text.length > RECAP_MAX) text.takeLast(RECAP_MAX) else text
    }

    companion object {
        const val RECAP_MAX = 1600
    }
}
