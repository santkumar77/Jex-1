package com.Jex.assistant.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class JexColorScheme(
    val background: Color,
    val backgroundGradientTop: Color,
    val surface: Color,
    val surfaceGlass: Color,
    val surfaceBorder: Color,
    val surfaceRaised: Color,
    val accent: Color,
    val accentSecondary: Color,
    val accentGlow: Color,
    val onAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val userBubble: Color,
    val assistantBubble: Color,
    val depthShadow: Color,
    val rimLight: Color,
    val lagoon: Color,
    val lotus: Color,
    val isDark: Boolean
) {
    companion object {
        val Dark = JexColorScheme(
            background = Color(0xFF06050E),
            backgroundGradientTop = Color(0xFF15113A),
            surface = Color(0xFF17143A),
            surfaceGlass = Color(0x66221E4D),
            surfaceBorder = Color(0x33FFFFFF),
            surfaceRaised = Color(0xFF221E4D),
            accent = Color(0xFFFFB547),
            accentSecondary = Color(0xFFFF8A3D),
            accentGlow = Color(0x55FFB547),
            onAccent = Color(0xFF1A1030),
            textPrimary = Color(0xFFEEE9FF),
            textSecondary = Color(0xFFA7A0CC),
            textTertiary = Color(0xFF7B74A3),
            success = Color(0xFF3FE0D0),
            warning = Color(0xFFFFB547),
            error = Color(0xFFFF7A85),
            userBubble = Color(0x33FFB547),
            assistantBubble = Color(0x55221E4D),
            depthShadow = Color(0x66000000),
            rimLight = Color(0x44FFFFFF),
            lagoon = Color(0xFF3FE0D0),
            lotus = Color(0xFFFF6FAE),
            isDark = true
        )

        val Light = JexColorScheme(
            background = Color(0xFFF3F0FB),
            backgroundGradientTop = Color(0xFFE5DFF8),
            surface = Color(0xFFFFFFFF),
            surfaceGlass = Color(0xB3FFFFFF),
            surfaceBorder = Color(0x1F15112E),
            surfaceRaised = Color(0xFFFFFFFF),
            accent = Color(0xFFB86A00),
            accentSecondary = Color(0xFFD9822B),
            accentGlow = Color(0x33B86A00),
            onAccent = Color(0xFFFFFFFF),
            textPrimary = Color(0xFF15112E),
            textSecondary = Color(0xFF4F4878),
            textTertiary = Color(0xFF7A7499),
            success = Color(0xFF0E8F83),
            warning = Color(0xFFB86A00),
            error = Color(0xFFC62C3B),
            userBubble = Color(0x26B86A00),
            assistantBubble = Color(0xCCFFFFFF),
            depthShadow = Color(0x2615112E),
            rimLight = Color(0xCCFFFFFF),
            lagoon = Color(0xFF0E8F83),
            lotus = Color(0xFFD13B80),
            isDark = false
        )
    }
}

val LocalJexColors = staticCompositionLocalOf { JexColorScheme.Dark }
val LocalJexReducedMotion = staticCompositionLocalOf { false }

object Jex {
    val colors: JexColorScheme
        @androidx.compose.runtime.Composable
        @androidx.compose.runtime.ReadOnlyComposable
        get() = LocalJexColors.current
}
