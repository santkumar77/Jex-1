package com.Jex.assistant.ui.theme

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin

/** Extra bottom padding so content can run under the floating nav bar. */
val LocalBottomBarInset = compositionLocalOf { PaddingValues(0.dp) }

/** Low-pass filtered device tilt in -1..1 (x = roll, y = pitch). Registered only while composed. */
@Composable
fun rememberTilt(enabled: Boolean = true): Pair<Float, Float> {
    val ctx = LocalContext.current
    var tilt by remember { mutableStateOf(0f to 0f) }
    DisposableEffect(enabled) {
        if (!enabled) {
            tilt = 0f to 0f
            return@DisposableEffect onDispose { }
        }
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var fx = 0f
        var fy = 0f
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = (-e.values[0] / 9.8f).coerceIn(-1f, 1f)
                val y = (e.values[1] / 9.8f).coerceIn(-1f, 1f)
                fx += (x - fx) * 0.08f
                fy += (y - fy) * 0.08f
                if (abs(fx - tilt.first) > 0.01f || abs(fy - tilt.second) > 0.01f) tilt = fx to fy
            }
            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        if (sm != null && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm?.unregisterListener(l) }
    }
    return tilt
}

/** Sparse deterministic star field + indigo gradient, optional tilt parallax. */
fun Modifier.nightSky(colors: JexColorScheme, tiltX: Float = 0f, tiltY: Float = 0f): Modifier = this
    .background(Brush.verticalGradient(listOf(colors.backgroundGradientTop, colors.background)))
    .drawBehind {
        if (!colors.isDark) return@drawBehind
        val count = 70
        for (i in 0 until count) {
            val sx = ((sin(i * 12.9898) * 43758.5453) % 1.0).toFloat().let { abs(it) }
            val sy = ((sin(i * 78.233) * 12345.6789) % 1.0).toFloat().let { abs(it) }
            val depth = 0.3f + (i % 5) * 0.15f
            val x = (sx * size.width + tiltX * 12.dp.toPx() * depth).mod(size.width)
            val y = (sy * size.height + tiltY * 12.dp.toPx() * depth).mod(size.height)
            val r = (0.6f + (i % 3) * 0.5f).dp.toPx()
            drawCircle(Color.White.copy(alpha = 0.10f + depth * 0.25f), r, Offset(x, y))
        }
    }

/** Coloured ambient shadow plus a top rim light. Cheap: no blur stacks. */
fun Modifier.depthSurface(
    colors: JexColorScheme,
    shape: Shape = RoundedCornerShape(20.dp),
    elevation: Dp = 6.dp,
    fill: Color = colors.surfaceGlass
): Modifier = this
    .shadow(elevation, shape, ambientColor = colors.accentGlow, spotColor = colors.depthShadow)
    .background(fill, shape)
    .border(1.dp, Brush.verticalGradient(listOf(colors.rimLight, colors.surfaceBorder)), shape)
