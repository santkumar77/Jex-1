package com.Jex.assistant.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.Jex.assistant.ui.components.JexTopBar
import com.Jex.assistant.ui.theme.LocalBottomBarInset

/** Standard scrolling screen: top bar + content that can run under the floating nav bar. */
@Composable
fun JexScreenColumn(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val inset = LocalBottomBarInset.current
    Column(modifier.fillMaxSize()) {
        JexTopBar(title, onBack, actions)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            content()
            Spacer(Modifier.height(inset.calculateBottomPadding() + 24.dp))
            Spacer(Modifier.navigationBarsPadding())
        }
    }
}
