package com.Jex.assistant.forge

import androidx.core.content.FileProvider

/** Own FileProvider subclass (own authority) so it never clashes with other providers. */
class ForgeFileProvider : FileProvider()
