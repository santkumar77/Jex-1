package com.Jex.assistant.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.Jex.assistant.ui.fx.JexOrbStyle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Plain class remembered once at the nav root. Every field has an applyX() that saves it.
 * (applyX, not setX, to avoid JVM setter clashes with Compose delegated properties.)
 */
class JexAppState(context: Context) {
    private val app: Context = context.applicationContext
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var themeMode by mutableStateOf(
        ThemeMode.fromName(JexPreferences.getString(app, JexPreferences.Keys.THEME_MODE, ThemeMode.DARK.name))
    )
        private set
    var reducedMotion by mutableStateOf(JexPreferences.getBoolean(app, JexPreferences.Keys.REDUCED_MOTION, false))
        private set
    var orbStyle by mutableStateOf(
        JexOrbStyle.fromName(JexPreferences.getString(app, JexPreferences.Keys.ORB_STYLE, JexOrbStyle.JEX.name))
    )
        private set
    var personality by mutableStateOf(
        Personality.fromName(JexPreferences.getString(app, JexPreferences.Keys.PERSONALITY, Personality.DEFAULT.name))
    )
        private set
    var assistantName by mutableStateOf(
        JexPreferences.getString(app, JexPreferences.Keys.ASSISTANT_NAME, AssistantBrand.NAME)
            .ifBlank { AssistantBrand.NAME }
    )
        private set
    var userName by mutableStateOf(JexPreferences.getString(app, JexPreferences.Keys.USER_NAME, ""))
        private set
    var language by mutableStateOf(
        LanguagePreference.fromName(JexPreferences.getString(app, JexPreferences.Keys.LANGUAGE, LanguagePreference.AUTO.name))
    )
        private set
    var voiceName by mutableStateOf(
        JexPreferences.getString(app, JexPreferences.Keys.VOICE_NAME, PersonalityRepository.DEFAULT_VOICE)
    )
        private set
    var speechSpeed by mutableFloatStateOf(JexPreferences.getFloat(app, JexPreferences.Keys.SPEECH_SPEED, 1f))
        private set
    var voiceVolume by mutableFloatStateOf(JexPreferences.getFloat(app, JexPreferences.Keys.VOICE_VOLUME, 1f))
        private set
    var hasOnboarded by mutableStateOf(JexPreferences.getBoolean(app, JexPreferences.Keys.HAS_ONBOARDED, false))
        private set

    // v3 toggles
    var readNotifications by mutableStateOf(JexPreferences.getBoolean(app, JexPreferences.Keys.READ_NOTIFICATIONS, false))
        private set
    var readSensitiveAloud by mutableStateOf(JexPreferences.getBoolean(app, JexPreferences.Keys.READ_SENSITIVE_ALOUD, false))
        private set
    var keepVisionBackground by mutableStateOf(JexPreferences.getBoolean(app, JexPreferences.Keys.KEEP_VISION_BACKGROUND, false))
        private set
    var notificationAllowApps by mutableStateOf(JexPreferences.getString(app, JexPreferences.Keys.NOTIFICATION_ALLOW_APPS))
        private set

    val conversations = mutableStateListOf<Conversation>().apply {
        addAll(Conversation.listFromJson(JexPreferences.getString(app, JexPreferences.Keys.CONVERSATIONS_JSON, "[]")))
    }

    fun applyThemeMode(v: ThemeMode) { themeMode = v; JexPreferences.putString(app, JexPreferences.Keys.THEME_MODE, v.name) }
    fun applyReducedMotion(v: Boolean) { reducedMotion = v; JexPreferences.putBoolean(app, JexPreferences.Keys.REDUCED_MOTION, v) }
    fun applyOrbStyle(v: JexOrbStyle) { orbStyle = v; JexPreferences.putString(app, JexPreferences.Keys.ORB_STYLE, v.name) }
    fun applyUserName(v: String) { userName = v.trim(); JexPreferences.putString(app, JexPreferences.Keys.USER_NAME, userName) }
    fun applySpeechSpeed(v: Float) { speechSpeed = v; JexPreferences.putFloat(app, JexPreferences.Keys.SPEECH_SPEED, v) }
    fun applyVoiceVolume(v: Float) {
        voiceVolume = v
        JexPreferences.putFloat(app, JexPreferences.Keys.VOICE_VOLUME, v)
        com.Jex.assistant.voice.VoiceSessionManager.applyVolume(v)
    }
    fun applyHasOnboarded(v: Boolean) { hasOnboarded = v; JexPreferences.putBoolean(app, JexPreferences.Keys.HAS_ONBOARDED, v) }
    fun applyReadNotifications(v: Boolean) { readNotifications = v; JexPreferences.putBoolean(app, JexPreferences.Keys.READ_NOTIFICATIONS, v) }
    fun applyReadSensitiveAloud(v: Boolean) { readSensitiveAloud = v; JexPreferences.putBoolean(app, JexPreferences.Keys.READ_SENSITIVE_ALOUD, v) }
    fun applyKeepVisionBackground(v: Boolean) { keepVisionBackground = v; JexPreferences.putBoolean(app, JexPreferences.Keys.KEEP_VISION_BACKGROUND, v) }
    fun applyNotificationAllowApps(v: String) { notificationAllowApps = v; JexPreferences.putString(app, JexPreferences.Keys.NOTIFICATION_ALLOW_APPS, v) }

    fun applyAssistantName(v: String) {
        val clean = v.trim().ifBlank { AssistantBrand.NAME }
        assistantName = clean
        JexPreferences.putString(app, JexPreferences.Keys.ASSISTANT_NAME, clean)
        io.launch { PersonalityRepository.setAssistantName(app, clean) }
    }

    fun applyLanguage(v: LanguagePreference) {
        language = v
        JexPreferences.putString(app, JexPreferences.Keys.LANGUAGE, v.name)
        io.launch { PersonalityRepository.setLanguage(app, v) }
    }

    fun applyPersonality(v: Personality) {
        personality = v
        JexPreferences.putString(app, JexPreferences.Keys.PERSONALITY, v.name)
        io.launch { PersonalityRepository.setPersonality(app, v) }
    }

    fun applyVoiceName(v: String) {
        voiceName = v
        JexPreferences.putString(app, JexPreferences.Keys.VOICE_NAME, v)
        io.launch { PersonalityRepository.setVoiceName(app, v) }
    }

    fun saveConversation(c: Conversation) {
        val idx = conversations.indexOfFirst { it.id == c.id }
        if (idx >= 0) conversations[idx] = c else conversations.add(0, c)
        persistConversations()
    }

    fun deleteConversation(id: Long) {
        conversations.removeAll { it.id == id }
        persistConversations()
    }

    fun clearConversations() {
        conversations.clear()
        persistConversations()
    }

    private fun persistConversations() {
        val json = Conversation.listToJson(conversations.toList())
        io.launch { JexPreferences.putString(app, JexPreferences.Keys.CONVERSATIONS_JSON, json) }
    }
}
