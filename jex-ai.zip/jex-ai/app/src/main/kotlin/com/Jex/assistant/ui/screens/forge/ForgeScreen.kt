package com.Jex.assistant.ui.screens.forge

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavHostController
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.forge.ForgeController
import com.Jex.assistant.forge.ForgePhase
import com.Jex.assistant.forge.ForgeStage
import com.Jex.assistant.forge.ForgeUiState
import com.Jex.assistant.ui.components.JexButton
import com.Jex.assistant.ui.components.JexButtonStyle
import com.Jex.assistant.ui.components.JexTextInputDialog
import com.Jex.assistant.ui.components.JexTopBar
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.depthSurface

@Composable
fun ForgeScreen(appState: JexAppState, nav: NavHostController) {
    val ctx = LocalContext.current
    val c = LocalJexColors.current
    val state by ForgeController.state.collectAsState()
    var fullscreen by remember { mutableStateOf(false) }
    var editDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        ForgeController.screenVisible = true
        onDispose { ForgeController.screenVisible = false }
    }
    BackHandler(fullscreen) { fullscreen = false }

    val file = state.file
    if (state.phase == ForgePhase.DONE && file != null && fullscreen) {
        Box(Modifier.fillMaxSize()) { GeneratedSiteView(file, state.buildId, Modifier.fillMaxSize()) }
        return
    }

    Column(Modifier.fillMaxSize()) {
        JexTopBar(if (state.phase == ForgePhase.DONE) "Your website" else "Forge", onBack = { nav.popBackStack() })
        when (state.phase) {
            ForgePhase.DONE -> if (file != null) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp).depthSurface(c, RoundedCornerShape(20.dp), 8.dp)) {
                    GeneratedSiteView(file, state.buildId, Modifier.fillMaxSize())
                }
                ResultToolbar(
                    onFullscreen = { fullscreen = true },
                    onShare = {
                        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.forge.fileprovider", file)
                        ctx.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("text/html").putExtra(Intent.EXTRA_STREAM, uri)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share website"
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                    onEdit = { editDialog = true },
                    onNew = { ForgeController.reset(); nav.popBackStack() }
                )
            }
            ForgePhase.FAILED, ForgePhase.CANCELLED -> Column(
                Modifier.weight(1f).fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Text(
                    if (state.phase == ForgePhase.CANCELLED) "Build cancelled." else (state.error ?: "Something went wrong."),
                    style = JexType.body.copy(color = c.textPrimary)
                )
                Spacer(Modifier.height(16.dp))
                JexButton("Try again", { ForgeController.retry(ctx) }, icon = Icons.Filled.Refresh)
            }
            ForgePhase.IDLE -> SavedSites(Modifier.weight(1f))
            else -> BuildingView(state, Modifier.weight(1f))
        }
        Spacer(Modifier.navigationBarsPadding())
    }

    if (editDialog) {
        JexTextInputDialog("What should I change?", "", "e.g. make the hero darker", onConfirm = { if (it.isNotBlank()) ForgeController.edit(ctx, it) }, onDismiss = { editDialog = false })
    }
}

@Composable
private fun BuildingView(state: ForgeUiState, modifier: Modifier) {
    val c = LocalJexColors.current
    Column(modifier.fillMaxWidth()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            ForgeWebGlScene(state, Modifier.fillMaxSize())
        }
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(state.prompt.take(80), style = JexType.voice.copy(color = c.textSecondary), maxLines = 1)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { state.progress }, Modifier.fillMaxWidth(), color = c.accent, trackColor = c.surfaceGlass)
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${(state.progress * 100).toInt()}%  ·  ${state.stage.label}", style = JexType.label.copy(color = c.textPrimary))
                Text(
                    "${state.metrics.chars / 1000} KB · ${state.metrics.sections} sections · ${state.metrics.elapsedSec}s · ~${state.metrics.tokensPerSec} tok/s",
                    style = JexType.caption.copy(color = c.textSecondary)
                )
            }
            Column(Modifier.padding(top = 10.dp)) {
                ForgeStage.entries.filter { it != ForgeStage.READY }.forEach { st ->
                    val done = st.ordinal < state.stage.ordinal
                    val active = st == state.stage
                    Text(
                        (if (done) "✓ " else if (active) "● " else "○ ") + st.label,
                        style = JexType.caption.copy(color = if (active) c.accent else if (done) c.lagoon else c.textTertiary)
                    )
                }
            }
            Column(Modifier.padding(top = 8.dp)) {
                state.log.takeLast(4).forEachIndexed { i, line ->
                    Text("› $line", style = JexType.caption.copy(color = c.textSecondary.copy(alpha = 0.4f + 0.15f * i)))
                }
            }
            JexButton("Cancel", { ForgeController.cancel() }, Modifier.padding(top = 10.dp), JexButtonStyle.TEXT)
        }
    }
}

@Composable
private fun ResultToolbar(onFullscreen: () -> Unit, onShare: () -> Unit, onEdit: () -> Unit, onNew: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        JexButton("Full", onFullscreen, Modifier.weight(1f), JexButtonStyle.SECONDARY, Icons.Filled.Fullscreen)
        JexButton("Share", onShare, Modifier.weight(1f), JexButtonStyle.SECONDARY, Icons.Filled.Share)
        JexButton("Edit", onEdit, Modifier.weight(1f), JexButtonStyle.PRIMARY, Icons.Filled.Edit)
        JexButton("New", onNew, Modifier.weight(1f), JexButtonStyle.TEXT)
    }
}

@Composable
private fun SavedSites(modifier: Modifier) {
    val ctx = LocalContext.current
    val c = LocalJexColors.current
    val files = remember { ForgeController.listSaved(ctx) }
    Column(modifier.fillMaxWidth().padding(16.dp)) {
        if (files.isEmpty()) {
            Text("No websites yet. Say or type \"build me a website for my cafe\".", style = JexType.voice.copy(color = c.textSecondary))
        } else {
            Text("Your websites", style = JexType.title.copy(color = c.textPrimary), modifier = Modifier.padding(bottom = 8.dp))
            files.forEach { f ->
                Text(
                    f.nameWithoutExtension, style = JexType.body.copy(color = c.accent),
                    modifier = Modifier.fillMaxWidth().clickable { ForgeController.openSaved(f) }.padding(vertical = 12.dp)
                )
            }
        }
    }
}
