package com.Jex.assistant.vision

/**
 * Vision Mode and Screen Share are separate frame sources. Starting one pauses the other's frame stream
 * unless the user asks for both ("dono chalu rakh"). Audio is shared and unaffected.
 */
object FrameSourceArbiter {
    enum class Source { VISION, SCREEN }

    private val running = linkedSetOf<Source>()
    @Volatile private var current: Source? = null
    @Volatile private var both = false

    @Synchronized
    fun start(source: Source, keepOther: Boolean = false) {
        running.add(source)
        both = keepOther && running.size > 1
        current = if (both) null else source
    }

    @Synchronized
    fun stop(source: Source) {
        running.remove(source)
        both = false
        current = running.lastOrNull()
    }

    @Synchronized
    fun enableBoth() {
        if (running.size > 1) { both = true; current = null }
    }

    /** True when this source may currently send frames to the model. */
    @Synchronized
    fun allowed(source: Source): Boolean = source in running && (both || current == source)

    @Synchronized fun isRunning(source: Source): Boolean = source in running

    @Synchronized fun reset() { running.clear(); current = null; both = false }
}

/** Pure math for frame throttling and downscaling (unit-tested). */
object FrameMath {
    /** Scales so the long edge is <= longEdge, keeping the aspect ratio. Never upscales. */
    fun scaledSize(width: Int, height: Int, longEdge: Int): Pair<Int, Int> {
        if (width <= 0 || height <= 0) return 1 to 1
        val long = maxOf(width, height)
        if (long <= longEdge) return width to height
        val s = longEdge.toDouble() / long
        return maxOf(1, (width * s).toInt()) to maxOf(1, (height * s).toInt())
    }

    fun shouldSend(nowMs: Long, lastSentMs: Long, intervalMs: Long): Boolean = lastSentMs <= 0L || nowMs - lastSentMs >= intervalMs

    /** Adaptive interval 500..2000 ms: slow down when the connection is busy, speed up when idle. */
    fun adaptiveInterval(currentMs: Long, busy: Boolean): Long =
        (if (busy) currentMs + 250 else currentMs - 100).coerceIn(500L, 2000L)

    fun normalizeRotation(deg: Int): Int = ((deg % 360) + 360) % 360
}
