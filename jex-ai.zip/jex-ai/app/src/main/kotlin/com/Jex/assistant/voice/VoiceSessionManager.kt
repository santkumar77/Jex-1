package com.Jex.assistant.voice

import android.content.Context
import com.Jex.assistant.action.ActionExecutor
import com.Jex.assistant.action.InstalledAppLabelCache
import com.Jex.assistant.data.ApiKeyStore
import com.Jex.assistant.data.JexPreferences
import com.Jex.assistant.data.LanguagePreference
import com.Jex.assistant.data.Personality
import com.Jex.assistant.data.PersonalityRepository
import com.Jex.assistant.forge.ForgeController
import com.Jex.assistant.forge.ForgeStartResult
import com.Jex.assistant.license.AccessKeyManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

/**
 * Process-wide voice session. Independent of any screen, so leaving a screen never kills the conversation.
 */
object VoiceSessionManager {
    private const val MAX_RECONNECTS = 5
    private const val RECONNECT_DELAY_MS = 1200L
    private const val PLAYBACK_SILENCE_MS = 300L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val epochCounter = AtomicInteger(0)

    private val _state = MutableStateFlow(JexOrbState.IDLE)
    val state: StateFlow<JexOrbState> = _state
    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude
    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted
    private val _statusText = MutableStateFlow("Tap Talk to start")
    val statusText: StateFlow<String> = _statusText
    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError
    private val _currentPersonality = MutableStateFlow(Personality.DEFAULT)
    val currentPersonality: StateFlow<Personality> = _currentPersonality
    private val _currentLanguage = MutableStateFlow(LanguagePreference.AUTO)
    val currentLanguage: StateFlow<LanguagePreference> = _currentLanguage
    private val _detectedLanguage = MutableStateFlow(DetectedLanguage.UNKNOWN)
    val detectedLanguage: StateFlow<DetectedLanguage> = _detectedLanguage
    private val _vadActive = MutableStateFlow(false)
    val vadActive: StateFlow<Boolean> = _vadActive

    val latency = VoiceLatencyTracker()
    val memory = ConversationMemory()

    @Volatile private var appCtx: Context? = null
    @Volatile private var client: GeminiLiveClient? = null
    @Volatile private var audio: LiveAudioIO? = null
    @Volatile private var micStarted = false
    @Volatile private var playbackActive = false
    @Volatile private var volume = 1f
    private var reconnectAttempts = 0
    private var reconnectJob: Job? = null
    private var silenceJob: Job? = null
    private var refreshJob: Job? = null
    private val pendingTexts = ArrayDeque<String>()

    val isLive: Boolean get() = client?.isReady == true

    fun start(ctx: Context) {
        if (_isActive.value) return
        val app = ctx.applicationContext
        appCtx = app
        if (!AccessKeyManager.isActive(app)) {
            fail(AccessKeyManager.blockedMessage(app))
            return
        }
        if (!ApiKeyStore.hasKey(app)) {
            fail("Add your Gemini API key in Settings first.")
            return
        }
        _lastError.value = null
        _isActive.value = true
        _state.value = JexOrbState.CONNECTING
        _statusText.value = "Connecting..."
        _amplitude.value = 0f
        _muted.value = false
        memory.clear()
        latency.reset()
        reconnectAttempts = 0
        VoiceLatencyTracker.resetReconnect()
        InstalledAppLabelCache.prewarm(app)
        volume = JexPreferences.getFloat(app, JexPreferences.Keys.VOICE_VOLUME, 1f)
        audio = LiveAudioIO(onMicChunk = ::forwardMic, onMicAmplitude = ::onMicAmplitude).also { it.setVolume(volume) }
        scope.launch { mutex.withLock { connectSession(isResuming = false) } }
    }

    private fun fail(message: String) {
        _lastError.value = message
        _state.value = JexOrbState.ERROR
        _statusText.value = message
    }

    private suspend fun connectSession(isResuming: Boolean) {
        val app = appCtx ?: return
        if (!_isActive.value) return
        val myEpoch = epochCounter.incrementAndGet()
        client?.let { it.listener = null; it.disconnect() }
        _state.value = JexOrbState.CONNECTING
        _statusText.value = if (isResuming) "Reconnecting..." else "Connecting..."

        val personality = PersonalityRepository.getPersonality(app)
        val language = PersonalityRepository.getLanguage(app)
        val name = PersonalityRepository.getAssistantName(app)
        val voice = mapVoice(PersonalityRepository.getVoiceName(app))
        _currentPersonality.value = personality
        _currentLanguage.value = language

        val prompt = PersonalityPromptBuilder.build(
            personality, language, _detectedLanguage.value,
            if (isResuming) memory.recap() else null, name
        )
        val newClient = GeminiLiveClient(ApiKeyStore.getKey(app))
        newClient.listener = makeListener(myEpoch)
        client = newClient
        newClient.connect(prompt, voice)
    }

    fun mapVoice(uiName: String): String {
        val known = setOf("Aoede", "Puck", "Charon", "Kore", "Fenrir", "Leda", "Orus", "Zephyr")
        return known.firstOrNull { it.equals(uiName.trim(), ignoreCase = true) } ?: "Aoede"
    }

    private fun makeListener(myEpoch: Int) = object : GeminiLiveClient.Listener {
        private fun stale() = epochCounter.get() != myEpoch || !_isActive.value

        override fun onSetupComplete() {
            if (stale()) return
            reconnectAttempts = 0
            _state.value = JexOrbState.LISTENING
            _statusText.value = "Listening..."
            startMicOnce()
            flushPending()
        }

        override fun onAudioChunk(bytes: ByteArray) {
            if (stale()) return
            if (!playbackActive) {
                playbackActive = true
                EchoGuard.notifyPlaybackStarted()
                latency.mark(VoiceLatencyTracker.Mark.FIRST_AUDIO)
            }
            val amp = audio?.playChunk(bytes) ?: 0f
            _amplitude.value = amp
            _state.value = JexOrbState.SPEAKING
            _statusText.value = "Speaking..."
            rearmSilenceWatchdog(myEpoch)
        }

        override fun onInputTranscript(text: String) {
            if (stale()) return
            memory.add(ConversationMemory.Role.USER, text)
            val d = LanguageDetector.detect(text)
            if (d != DetectedLanguage.UNKNOWN) _detectedLanguage.value = d
            latency.mark(VoiceLatencyTracker.Mark.FIRST_TRANSCRIPT)
        }

        override fun onOutputTranscript(text: String) {
            if (stale()) return
            memory.add(ConversationMemory.Role.ASSISTANT, text)
        }

        override fun onToolCall(id: String, name: String, args: JSONObject) {
            if (stale()) return
            _state.value = JexOrbState.THINKING
            _statusText.value = "Working on it..."
            scope.launch {
                val result = try {
                    handleTool(name, args)
                } catch (e: Exception) {
                    JSONObject().put("status", "failed").put("error", "tool_failed")
                }
                if (!stale()) {
                    client?.sendToolResponse(id, name, result)
                    if (_state.value == JexOrbState.THINKING) {
                        _state.value = JexOrbState.LISTENING
                        _statusText.value = "Listening..."
                    }
                }
            }
        }

        override fun onTurnComplete() {
            if (stale()) return
            endPlayback()
            latency.mark(VoiceLatencyTracker.Mark.TURN_COMPLETE)
            latency.reset()
            _state.value = JexOrbState.LISTENING
            _statusText.value = "Listening..."
        }

        override fun onInterrupted() {
            if (stale()) return
            audio?.flushPlayback()
            endPlayback()
            _state.value = JexOrbState.LISTENING
            _statusText.value = "Listening..."
        }

        override fun onError(message: String) {
            if (stale()) return
            _lastError.value = message
            scheduleReconnect()
        }

        override fun onClosed() {
            if (stale()) return
            scheduleReconnect()
        }
    }

    private suspend fun handleTool(name: String, args: JSONObject): JSONObject {
        val app = appCtx ?: return JSONObject().put("status", "failed").put("error", "no_context")
        if (name == "build_website") {
            val prompt = args.optString("prompt").ifBlank { args.optString("description") }
            return when (val r = ForgeController.start(app, prompt)) {
                is ForgeStartResult.Started -> JSONObject().put("result", "forge_started")
                else -> JSONObject().put("result", "forge_not_started").put("message", r.message)
            }
        }
        return ActionExecutor.execute(app, name, args)
    }

    private fun startMicOnce() {
        if (micStarted) return
        val ok = audio?.startMic() ?: false
        if (ok) {
            micStarted = true
        } else {
            _lastError.value = "Microphone is unavailable. Check the microphone permission."
        }
    }

    private fun forwardMic(bytes: ByteArray) {
        if (_muted.value || EchoGuard.isMicMuted()) return
        client?.sendAudio(bytes)
    }

    private fun onMicAmplitude(rms: Float) {
        _vadActive.value = rms > 0.02f
        if (_state.value == JexOrbState.LISTENING) _amplitude.value = rms
    }

    private fun rearmSilenceWatchdog(myEpoch: Int) {
        silenceJob?.cancel()
        silenceJob = scope.launch {
            delay(PLAYBACK_SILENCE_MS)
            if (epochCounter.get() == myEpoch && playbackActive) {
                endPlayback()
                if (_state.value == JexOrbState.SPEAKING) {
                    _state.value = JexOrbState.LISTENING
                    _statusText.value = "Listening..."
                }
            }
        }
    }

    private fun endPlayback() {
        silenceJob?.cancel()
        if (playbackActive) {
            playbackActive = false
            EchoGuard.notifyPlaybackStopped()
        }
        _amplitude.value = 0f
    }

    private fun scheduleReconnect() {
        if (!_isActive.value) return
        synchronized(this) {
            if (reconnectJob?.isActive == true) return
            reconnectJob = scope.launch {
                if (reconnectAttempts >= MAX_RECONNECTS) {
                    _state.value = JexOrbState.ERROR
                    _lastError.value = "Connection lost - tap Stop and reopen Voice Mode"
                    _statusText.value = "Connection lost - tap Stop and reopen Voice Mode"
                    return@launch
                }
                reconnectAttempts++
                VoiceLatencyTracker.incrementReconnect()
                endPlayback()
                _state.value = JexOrbState.CONNECTING
                _statusText.value = "Reconnecting..."
                delay(RECONNECT_DELAY_MS)
                mutex.withLock { if (_isActive.value) connectSession(isResuming = true) }
            }
        }
    }

    /** Live cannot change the system instruction mid-session, so reconnect (with a recap). */
    fun refreshInstructions(ctx: Context) {
        if (!_isActive.value) return
        appCtx = ctx.applicationContext
        refreshJob?.cancel()
        refreshJob = scope.launch {
            delay(350)
            mutex.withLock { if (_isActive.value) connectSession(isResuming = true) }
        }
    }

    fun toggleMute() {
        _muted.value = !_muted.value
    }

    fun applyVolume(v: Float) {
        volume = v
        audio?.setVolume(v)
    }

    /** Queue or send a short text for Jex to speak/handle (notifications, call summaries). */
    fun say(text: String) {
        val c = client
        if (c != null && c.isReady) c.sendText(text) else synchronized(pendingTexts) { pendingTexts.addLast(text) }
    }

    private fun flushPending() {
        val c = client ?: return
        val items = synchronized(pendingTexts) { val l = pendingTexts.toList(); pendingTexts.clear(); l }
        items.forEach { c.sendText(it) }
    }

    /** One camera / screen frame for the model (vision mode and screen share). */
    fun sendVideoFrame(jpeg: ByteArray) {
        val c = client ?: return
        if (c.isReady) c.sendImageFrame(jpeg)
    }

    fun isSpeaking(): Boolean = _state.value == JexOrbState.SPEAKING

    fun stop() {
        reconnectJob?.cancel()
        silenceJob?.cancel()
        refreshJob?.cancel()
        epochCounter.incrementAndGet()
        client?.let { it.listener = null; it.disconnect() }
        client = null
        audio?.release()
        audio = null
        micStarted = false
        playbackActive = false
        EchoGuard.reset()
        memory.clear()
        synchronized(pendingTexts) { pendingTexts.clear() }
        _isActive.value = false
        _state.value = JexOrbState.IDLE
        _amplitude.value = 0f
        _vadActive.value = false
        _statusText.value = "Tap Talk to start"
    }
}
