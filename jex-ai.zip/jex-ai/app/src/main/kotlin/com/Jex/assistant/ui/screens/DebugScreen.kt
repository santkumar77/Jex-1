package com.Jex.assistant.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.voice.VoiceLatencyTracker
import com.Jex.assistant.voice.VoiceSessionManager

@Composable
fun DebugScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    val state by VoiceSessionManager.state.collectAsState()
    val active by VoiceSessionManager.isActive.collectAsState()
    val personality by VoiceSessionManager.currentPersonality.collectAsState()
    val language by VoiceSessionManager.currentLanguage.collectAsState()
    val detected by VoiceSessionManager.detectedLanguage.collectAsState()
    val vad by VoiceSessionManager.vadActive.collectAsState()
    val muted by VoiceSessionManager.muted.collectAsState()
    val reconnects by VoiceLatencyTracker.reconnectCount.collectAsState()
    val err by VoiceSessionManager.lastError.collectAsState()
    val lat = VoiceSessionManager.latency

    @Composable
    fun line(k: String, v: String) = Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text(k, style = JexType.label.copy(color = c.textSecondary), modifier = Modifier.weight(1f))
        Text(v, style = JexType.label.copy(color = c.textPrimary))
    }

    JexScreenColumn("Voice pipeline debugger", onBack = { nav.popBackStack() }) {
        SectionCard {
            Column(Modifier.padding(vertical = 8.dp)) {
                line("Session", if (active) "active" else "stopped")
                line("Connection state", state.name)
                line("Personality", personality.displayName)
                line("Language (configured)", language.displayName)
                line("Language (detected)", detected.name)
                line("Voice activity", if (vad) "speech" else "quiet")
                line("Mic", if (muted) "muted" else "live")
                line("Reconnects", reconnects.toString())
                line("Last turn: speech end to first audio", lat.toFirstAudio()?.let { "$it ms" } ?: "n/a")
                line("Last turn: total", lat.toTurnComplete()?.let { "$it ms" } ?: "n/a")
                if (err != null) line("Last error", err ?: "")
            }
        }
        FlavorDebugSection()
    }
}
