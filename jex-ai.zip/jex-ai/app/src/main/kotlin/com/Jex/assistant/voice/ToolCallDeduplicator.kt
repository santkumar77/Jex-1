package com.Jex.assistant.voice

/** Bounded set of seen tool-call ids. A call id seen before is skipped. */
class ToolCallDeduplicator(private val capacity: Int = 128) {
    private val seen = LinkedHashSet<String>()

    /** Returns true when this id is new (and records it); false when it was already seen. */
    @Synchronized
    fun firstTime(id: String): Boolean {
        if (id.isEmpty()) return true
        if (seen.contains(id)) return false
        seen.add(id)
        while (seen.size > capacity) {
            val it = seen.iterator()
            it.next()
            it.remove()
        }
        return true
    }

    @Synchronized
    fun clear() = seen.clear()
}
