package com.Jex.assistant.data

import android.content.Context

/** Small typed wrapper over the "jex_prefs" SharedPreferences file. */
object JexPreferences {
    private const val FILE = "jex_prefs"

    object Keys {
        const val THEME_MODE = "theme_mode"
        const val REDUCED_MOTION = "reduced_motion"
        const val ORB_STYLE = "orb_style"
        const val PERSONALITY = "personality"
        const val USER_NAME = "user_name"
        const val VOICE_INPUT_ENABLED = "voice_input_enabled"
        const val WAKE_WORD_ENABLED = "wake_word_enabled"
        const val LANGUAGE = "language"
        const val HAS_ONBOARDED = "has_onboarded"
        const val VOICE_NAME = "voice_name"
        const val RESPONSE_STYLE = "response_style"
        const val SPEECH_SPEED = "speech_speed"
        const val VOICE_VOLUME = "voice_volume"
        const val ASSISTANT_NAME = "assistant_name"

        // v3 additions
        const val READ_NOTIFICATIONS = "read_notifications"
        const val NOTIFICATION_ALLOW_APPS = "notification_allow_apps" // comma separated packages, empty = all
        const val NOTIFICATION_DENY_APPS = "notification_deny_apps"
        const val READ_SENSITIVE_ALOUD = "read_sensitive_aloud"
        const val KEEP_VISION_BACKGROUND = "keep_vision_background"
        const val CONVERSATIONS_JSON = "conversations_json"
        const val CONTACT_STORE_JSON = "contact_store_json"
        const val TASK_LOG_JSON = "task_log_json"
        const val CALL_COUNT_DAY = "call_count_day"
        const val CALL_COUNT = "call_count"
    }

    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getString(ctx: Context, key: String, default: String = ""): String =
        p(ctx).getString(key, default) ?: default

    fun putString(ctx: Context, key: String, value: String) {
        p(ctx).edit().putString(key, value).apply()
    }

    fun getBoolean(ctx: Context, key: String, default: Boolean = false): Boolean =
        p(ctx).getBoolean(key, default)

    fun putBoolean(ctx: Context, key: String, value: Boolean) {
        p(ctx).edit().putBoolean(key, value).apply()
    }

    fun getFloat(ctx: Context, key: String, default: Float = 0f): Float =
        p(ctx).getFloat(key, default)

    fun putFloat(ctx: Context, key: String, value: Float) {
        p(ctx).edit().putFloat(key, value).apply()
    }

    fun getInt(ctx: Context, key: String, default: Int = 0): Int = p(ctx).getInt(key, default)

    fun putInt(ctx: Context, key: String, value: Int) {
        p(ctx).edit().putInt(key, value).apply()
    }
}
