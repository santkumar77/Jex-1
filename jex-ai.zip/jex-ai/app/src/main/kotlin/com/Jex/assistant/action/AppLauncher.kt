package com.Jex.assistant.action

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent

object AppLauncher {

    /** Pure matching used by tests: label -> package map and a spoken query. Never loose substring matching. */
    fun findApp(labels: Map<String, String>, query: String): Pair<String, String>? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        labels[q]?.let { return q to it }
        val qWords = q.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val candidates = labels.entries.filter { (key, _) ->
            key.length >= 3 && (
                key.startsWith(q) || q.startsWith(key) ||
                    qWords.all { w -> key.split(Regex("\\s+")).any { kw -> kw.startsWith(w) } }
                )
        }
        val best = candidates.minByOrNull { kotlin.math.abs(it.key.length - q.length) } ?: return null
        return best.key to best.value
    }

    suspend fun findApp(ctx: Context, query: String): Pair<String, String>? =
        findApp(InstalledAppLabelCache.get(ctx), query)

    fun launch(ctx: Context, pkg: String): Boolean {
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            ctx.startActivity(i)
            true
        } catch (ignored: ActivityNotFoundException) {
            false
        } catch (ignored: SecurityException) {
            false
        }
    }
}
