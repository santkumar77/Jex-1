package com.Jex.assistant.ui.fx

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.withFrameNanos
import com.Jex.assistant.ui.theme.LocalJexReducedMotion
import com.Jex.assistant.ui.theme.rememberTilt
import com.Jex.assistant.voice.JexOrbState

private const val ORB_AGSL = """
uniform float2 resolution;
uniform float time;
uniform float amp;
uniform float speed;
uniform float2 tilt;
uniform float3 coreCol;
uniform float3 rimCol;
uniform float3 haloCol;

float hash(float2 p) { return fract(sin(dot(p, float2(127.1, 311.7))) * 43758.5453); }
float noise(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + float2(1.0, 0.0));
    float c = hash(i + float2(0.0, 1.0));
    float d = hash(i + float2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(float2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * noise(p);
        p = p * 2.02 + float2(1.7, 9.2);
        a *= 0.5;
    }
    return v;
}

half4 main(float2 frag) {
    float2 uv = (frag - 0.5 * resolution) / (0.5 * min(resolution.x, resolution.y));
    uv.y = -uv.y;
    float R = 0.70 + amp * 0.14;
    float d = length(uv);
    if (d > R) {
        float h = exp(-(d - R) * 5.5) * (0.5 + amp * 0.5);
        float3 hc = haloCol * h;
        return half4(half3(hc), half(h));
    }
    float z = sqrt(max(R * R - d * d, 0.0)) / R;
    float3 n = normalize(float3(uv / R, z));
    float3 L = normalize(float3(-0.45 + tilt.x * 0.9, 0.55 + tilt.y * 0.9, 0.8));
    float diff = max(dot(n, L), 0.0);
    float3 refl = reflect(-L, n);
    float spec = pow(max(refl.z, 0.0), 36.0);
    float fres = pow(1.0 - z, 3.0);
    float t = time * speed;
    float2 p = n.xy * 2.2 + float2(cos(t * 0.35), sin(t * 0.35)) * 0.6;
    float e = fbm(p + fbm(p + t * 0.25));
    float3 body = mix(coreCol * 0.30, coreCol, e) * (0.35 + 0.95 * diff);
    body += coreCol * amp * 0.45 * (1.0 - d / R);
    body += rimCol * fres * (0.85 + amp);
    body += float3(1.0) * spec * 0.55;
    float edge = smoothstep(R, R - 0.015, d);
    return half4(half3(body * edge), half(edge));
}
"""

@Composable
fun JexOrb3D(
    state: JexOrbState,
    size: Dp,
    amplitude: Float,
    modifier: Modifier = Modifier,
    style: JexOrbStyle = JexOrbStyle.JEX
) {
    if (Build.VERSION.SDK_INT < 33 || style == JexOrbStyle.ARCHER) {
        JexCanvasOrb(state, style, size, amplitude, modifier)
        return
    }
    OrbShaderCanvas(state, size, amplitude, modifier, style)
}

@Composable
private fun OrbShaderCanvas(state: JexOrbState, size: Dp, amplitude: Float, modifier: Modifier, style: JexOrbStyle) {
    val reduced = LocalJexReducedMotion.current
    val (tiltX, tiltY) = rememberTilt(enabled = !reduced)
    val shader = remember { RuntimeShader(ORB_AGSL) }
    var time by remember { mutableFloatStateOf(0f) }
    val (core, rim, halo) = animatedOrbColors(state, style)
    LaunchedEffect(reduced) {
        if (reduced) return@LaunchedEffect
        val start = withFrameNanos { it }
        while (true) withFrameNanos { time = (it - start) / 1_000_000_000f }
    }
    val speed = when (state) {
        JexOrbState.THINKING -> 2.4f
        JexOrbState.CONNECTING -> 0.7f
        JexOrbState.LISTENING -> 1.0f
        JexOrbState.SPEAKING -> 1.4f
        else -> 0.8f
    }
    val breathing = if (state == JexOrbState.LISTENING && !reduced) 0.06f * (1f + kotlin.math.sin(time * 1.6f)) / 2f else 0f
    val amp = (if (state == JexOrbState.SPEAKING) amplitude * 1.6f else amplitude * 0.5f).coerceIn(0f, 1f) + breathing
    val desc = "Jex status: ${state.name.lowercase()}"
    Canvas(modifier.size(size).clipToBounds().semantics { contentDescription = desc }) {
        shader.setFloatUniform("resolution", this.size.width, this.size.height)
        shader.setFloatUniform("time", time)
        shader.setFloatUniform("amp", amp.coerceIn(0f, 1f))
        shader.setFloatUniform("speed", speed)
        shader.setFloatUniform("tilt", tiltX, tiltY)
        shader.setFloatUniform("coreCol", core.value.red, core.value.green, core.value.blue)
        shader.setFloatUniform("rimCol", rim.value.red, rim.value.green, rim.value.blue)
        shader.setFloatUniform("haloCol", halo.value.red, halo.value.green, halo.value.blue)
        drawRect(brush = ShaderBrush(shader))
    }
}
