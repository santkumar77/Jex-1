package com.Jex.assistant.voice

import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Mutes the mic while Jex's own voice plays (so a loudspeaker never feeds Jex back to itself),
 * with a 450 ms tail after playback ends and a 60 s watchdog.
 */
object EchoGuard {
    var ECHO_TAIL_MS = 450L
    const val WATCHDOG_MS = 60_000L

    @Volatile var scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile var clock: () -> Long = { SystemClock.elapsedRealtime() }

    private val lock = Any()
    private var active = 0
    @Volatile private var mutedUntil = 0L
    @Volatile private var playing = false
    private var tailJob: Job? = null
    private var watchdogJob: Job? = null

    /** Stricter half-duplex mode for calls: longer tail. */
    @Volatile var strict = false

    fun notifyPlaybackStarted() {
        synchronized(lock) {
            active++
            playing = true
            tailJob?.cancel()
            watchdogJob?.cancel()
            watchdogJob = scope.launch {
                delay(WATCHDOG_MS)
                forceUnmute()
            }
        }
    }

    fun notifyPlaybackStopped() {
        synchronized(lock) {
            if (active > 0) active--
            if (active == 0) {
                watchdogJob?.cancel()
                val tail = if (strict) ECHO_TAIL_MS + 350 else ECHO_TAIL_MS
                mutedUntil = clock() + tail
                tailJob?.cancel()
                tailJob = scope.launch {
                    delay(tail)
                    synchronized(lock) { if (active == 0) playing = false }
                }
            }
        }
    }

    fun isMicMuted(): Boolean = synchronized(lock) {
        playing && (active > 0 || clock() < mutedUntil)
    }

    private fun forceUnmute() {
        synchronized(lock) {
            active = 0
            playing = false
            mutedUntil = 0L
        }
    }

    fun activeCount(): Int = synchronized(lock) { active }

    fun reset() {
        synchronized(lock) {
            tailJob?.cancel()
            watchdogJob?.cancel()
            active = 0
            playing = false
            mutedUntil = 0L
            strict = false
        }
    }
}
