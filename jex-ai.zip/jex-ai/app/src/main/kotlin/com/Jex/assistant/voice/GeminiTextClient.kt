package com.Jex.assistant.voice

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatTurn(val isUser: Boolean, val text: String)

sealed class ChatReplyResult {
    data class Success(val text: String) : ChatReplyResult()
    data class Error(val message: String) : ChatReplyResult()
}

/** REST text client. Never hardcodes a model id: resolves one via ListModels. Never logs key or user text. */
object GeminiTextClient {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private const val TAG = "GeminiText"
    private val JSON = "application/json; charset=utf-8".toMediaType()

    internal val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    @Volatile private var cachedModel: String? = null

    /** Pure selection rule so it can be unit-tested. */
    internal fun pickModel(models: JSONArray): String? {
        var firstAny: String? = null
        for (i in 0 until models.length()) {
            val m = models.optJSONObject(i) ?: continue
            val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
            var ok = false
            for (j in 0 until methods.length()) if (methods.optString(j) == "generateContent") ok = true
            if (!ok) continue
            val name = m.optString("name").removePrefix("models/")
            if (firstAny == null) firstAny = name
            val lower = name.lowercase()
            if (lower.contains("flash") && listOf("live", "image", "tts").none { lower.contains(it) }) return name
        }
        return firstAny
    }

    internal fun resolveModel(apiKey: String): String? {
        cachedModel?.let { return it }
        val req = Request.Builder().url("$BASE/models?key=$apiKey").get().build()
        return try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    Log.w(TAG, "ListModels failed: HTTP ${resp.code}")
                    return null
                }
                val body = JSONObject(resp.body?.string().orEmpty())
                val picked = pickModel(body.optJSONArray("models") ?: JSONArray())
                cachedModel = picked
                picked
            }
        } catch (ignored: Exception) {
            null
        }
    }

    fun reply(apiKey: String, systemInstruction: String, history: List<ChatTurn>): ChatReplyResult {
        if (apiKey.isBlank()) return ChatReplyResult.Error("Add your Gemini API key in Settings first.")
        if (history.isEmpty()) return ChatReplyResult.Error("Nothing to answer yet.")
        val model = resolveModel(apiKey) ?: return ChatReplyResult.Error("Couldn't find a Gemini model. Check your API key and internet.")
        val contents = JSONArray()
        history.forEach {
            contents.put(
                JSONObject().put("role", if (it.isUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        val payload = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))))
            .put("contents", contents)
        val req = Request.Builder()
            .url("$BASE/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(payload.toString().toRequestBody(JSON))
            .build()
        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    val reason = try { JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty() } catch (ignored: Exception) { "" }
                    Log.w(TAG, "generateContent HTTP ${resp.code}: ${reason.take(160)}")
                    return ChatReplyResult.Error(friendlyHttp(resp.code, reason))
                }
                val text = try {
                    JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty()
                } catch (ignored: Exception) { "" }
                if (text.isBlank()) ChatReplyResult.Error("Gemini sent an empty or blocked reply. Try asking differently.")
                else ChatReplyResult.Success(text.trim())
            }
        } catch (ignored: IOException) {
            ChatReplyResult.Error("Couldn't reach Gemini. Check your internet and try again.")
        }
    }

    fun friendlyHttp(code: Int, reason: String): String = when (code) {
        400, 401, 403 -> "Gemini rejected the request (HTTP $code). Check your API key in Settings."
        429 -> "Gemini is rate-limiting you. Wait a little and try again."
        503 -> "Gemini is busy right now. Please try again in a moment."
        else -> "Gemini error (HTTP $code)." + if (reason.isNotBlank()) " ${reason.take(120)}" else ""
    }
}
