package com.Jex.assistant.action

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

sealed class ContactResult {
    data class Found(val name: String, val number: String) : ContactResult()
    object NoPermission : ContactResult()
    object NotFound : ContactResult()
}

data class ContactEntry(val name: String, val number: String)

object ContactResolver {

    fun looksLikePhoneNumber(q: String): Boolean {
        val t = q.trim()
        if (t.isEmpty()) return false
        if (!t.all { it.isDigit() || it in " +-()." }) return false
        return t.count { it.isDigit() } >= 5
    }

    /** exact(0) > prefix(1) > contains(2). */
    fun rank(name: String, query: String): Int {
        val n = name.lowercase().trim()
        val q = query.lowercase().trim()
        return when {
            n == q -> 0
            n.startsWith(q) -> 1
            n.contains(q) -> 2
            else -> 3
        }
    }

    fun pickBest(entries: List<ContactEntry>, query: String): ContactEntry? =
        entries.filter { rank(it.name, query) < 3 }.minByOrNull { rank(it.name, query) }

    fun lookup(ctx: Context, query: String): ContactResult {
        val q = query.trim()
        if (looksLikePhoneNumber(q)) return ContactResult.Found(q, q.filter { it.isDigit() || it == '+' })
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return ContactResult.NoPermission
        }
        val list = searchAll(ctx, q)
        val best = pickBest(list, q) ?: return ContactResult.NotFound
        return ContactResult.Found(best.name, best.number)
    }

    /** Ambiguity helper for the call agent: distinct people matching the query. */
    fun matches(ctx: Context, query: String): List<ContactEntry> {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        return searchAll(ctx, query.trim()).distinctBy { it.name.lowercase() }
    }

    private fun searchAll(ctx: Context, q: String): List<ContactEntry> {
        val out = ArrayList<ContactEntry>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$q%"),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC LIMIT 5"
            )?.use { c ->
                while (c.moveToNext()) out.add(ContactEntry(c.getString(0).orEmpty(), c.getString(1).orEmpty()))
            }
        } catch (ignored: Exception) {
        }
        return out
    }
}
