package com.Jex.assistant.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavHostController
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.MinTouchTarget

enum class PermStatus { GRANTED, DENIED, OPTIONAL }

/** A row with a status light (green / amber / red). Tap = grant or open settings. */
@Composable
fun PermissionRow(title: String, subtitle: String, status: PermStatus, actionLabel: String, onClick: () -> Unit) {
    val c = LocalJexColors.current
    val light: Color = when (status) {
        PermStatus.GRANTED -> c.lagoon
        PermStatus.OPTIONAL -> c.warning
        PermStatus.DENIED -> c.error
    }
    Row(
        Modifier.fillMaxWidth().heightIn(min = 60.dp).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.size(12.dp).background(light, CircleShape))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = JexType.title.copy(color = c.textPrimary))
            Text(subtitle, style = JexType.caption.copy(color = c.textSecondary))
        }
        Text(if (status == PermStatus.GRANTED) "On" else actionLabel, style = JexType.label.copy(color = if (status == PermStatus.GRANTED) c.lagoon else c.accent))
    }
}

/** Increments each time the screen resumes so statuses are re-read. */
@Composable
fun rememberResumeTick(): Int {
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    return tick
}

@Composable
fun PermissionsScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun status(p: String) = if (has(p)) PermStatus.GRANTED else PermStatus.DENIED
    fun openAppSettings() {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    JexScreenColumn("Permissions", onBack = { nav.popBackStack() }) {
        @Suppress("UNUSED_EXPRESSION") tick
        SectionCard {
            Column {
                PermissionRow("Microphone", "Needed to hear you", status(Manifest.permission.RECORD_AUDIO), "Allow") {
                    if (has(Manifest.permission.RECORD_AUDIO)) openAppSettings() else launcher.launch(Manifest.permission.RECORD_AUDIO)
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    PermissionRow("Notifications", "Voice session and website-ready alerts", status(Manifest.permission.POST_NOTIFICATIONS), "Allow") {
                        if (has(Manifest.permission.POST_NOTIFICATIONS)) openAppSettings() else launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                PermissionRow("Contacts", "To find who you want to call or message", status(Manifest.permission.READ_CONTACTS), "Allow") {
                    if (has(Manifest.permission.READ_CONTACTS)) openAppSettings() else launcher.launch(Manifest.permission.READ_CONTACTS)
                }
                PermissionRow("Phone calls", "To place calls directly (otherwise the dialer opens)", status(Manifest.permission.CALL_PHONE), "Allow") {
                    if (has(Manifest.permission.CALL_PHONE)) openAppSettings() else launcher.launch(Manifest.permission.CALL_PHONE)
                }
                PermissionRow("Camera", "For Vision Mode", status(Manifest.permission.CAMERA), "Allow") {
                    if (has(Manifest.permission.CAMERA)) openAppSettings() else launcher.launch(Manifest.permission.CAMERA)
                }
            }
        }
        FlavorPermissionRows(tick)
    }
}
