package com.Jex.assistant.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Brand fonts: Instrument Serif (display / "voice") and Manrope (UI).
 * They are OFL-licensed; to bundle them, drop the .ttf files into res/font
 * (instrument_serif_regular.ttf, instrument_serif_italic.ttf, manrope_variable.ttf) and replace the two
 * families below with Font(R.font.xxx) lists. Until then the system serif / sans-serif are used,
 * so the app builds and looks right without extra assets.
 */
object JexFonts {
    val Serif: FontFamily = FontFamily.Serif
    val Sans: FontFamily = FontFamily.SansSerif
}

object JexType {
    val display = TextStyle(fontFamily = JexFonts.Serif, fontSize = 40.sp, lineHeight = 46.sp, fontWeight = FontWeight.Normal)
    val headline = TextStyle(fontFamily = JexFonts.Serif, fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Normal)
    val voice = TextStyle(fontFamily = JexFonts.Serif, fontSize = 20.sp, lineHeight = 26.sp, fontStyle = FontStyle.Italic)
    val title = TextStyle(fontFamily = JexFonts.Sans, fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold)
    val body = TextStyle(fontFamily = JexFonts.Sans, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal)
    val label = TextStyle(fontFamily = JexFonts.Sans, fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium)
    val caption = TextStyle(fontFamily = JexFonts.Sans, fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)
}

val JexTypography = Typography(
    displayLarge = JexType.display,
    headlineMedium = JexType.headline,
    titleMedium = JexType.title,
    bodyLarge = JexType.body,
    bodyMedium = JexType.body,
    labelLarge = JexType.label,
    labelMedium = JexType.label,
    bodySmall = JexType.caption
)
