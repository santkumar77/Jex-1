package com.Jex.assistant.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.R
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.license.AccessKeyBanner
import com.Jex.assistant.ui.components.JexButton
import com.Jex.assistant.ui.components.JexButtonStyle
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.fx.JexOrb3D
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalBottomBarInset
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.MinTouchTarget
import com.Jex.assistant.ui.theme.depthSurface
import com.Jex.assistant.voice.VoiceSessionManager
import java.util.Calendar

fun greetingFor(hour: Int): String = when (hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..21 -> "Good evening"
    else -> "Good night"
}

private val TRY_SAYING = listOf(
    "YouTube kholo", "Mummy ko call karo", "Ek cafe ki website banao", "Mujhe ek joke sunao", "What's on my screen?"
)

@Composable
fun HomeScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    val state by VoiceSessionManager.state.collectAsState()
    val amp by VoiceSessionManager.amplitude.collectAsState()
    val inset = LocalBottomBarInset.current
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val name = appState.userName.ifBlank { "" }
    val greeting = greetingFor(hour) + if (name.isNotBlank()) ", $name" else ""

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).depthSurface(c, CircleShape, 6.dp).clip(CircleShape), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.jex_logo), "Jex AI logo", Modifier.size(34.dp))
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(MinTouchTarget).depthSurface(c, CircleShape, 6.dp).clip(CircleShape).clickable { nav.navigate(Routes.PROFILE) },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Person, "Profile", tint = c.textPrimary) }
        }
        AccessKeyBanner(nav)
        Text(
            greeting, style = JexType.display.copy(color = c.textPrimary, fontSize = JexType.display.fontSize * 0.8f),
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp)
        )
        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val orbSize = maxWidth * 0.55f
            Box(Modifier.clip(CircleShape).clickable { nav.navigate(Routes.VOICE) }) {
                JexOrb3D(state, orbSize, amp, style = appState.orbStyle)
            }
        }
        Text(
            "Tap me to talk", style = JexType.voice.copy(color = c.textSecondary),
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            JexButton("Talk", { nav.navigate(Routes.VOICE) }, Modifier.weight(1f), JexButtonStyle.PRIMARY, Icons.Filled.Mic)
            JexButton("Type", { nav.navigate(Routes.CHAT) }, Modifier.weight(1f), JexButtonStyle.SECONDARY, Icons.Filled.Keyboard)
        }
        Text(
            "Try saying", style = JexType.label.copy(color = c.accent),
            modifier = Modifier.padding(start = 24.dp, top = 24.dp, bottom = 8.dp)
        )
        LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(TRY_SAYING) { phrase ->
                JexGlassCard(Modifier.graphicsLayer { rotationY = -4f; cameraDistance = 14f * density }) {
                    Text(
                        "\u201C$phrase\u201D", style = JexType.body.copy(color = c.textPrimary),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
                    )
                }
            }
        }
        JexButton(
            "Quick actions", { nav.navigate(Routes.QUICK_ACTIONS) },
            Modifier.padding(horizontal = 24.dp, vertical = 20.dp), JexButtonStyle.TEXT
        )
        Spacer(Modifier.height(inset.calculateBottomPadding() + 16.dp))
    }
}
