package com.Jex.assistant.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Per-turn timestamps and derived deltas. Marks must arrive in order; out-of-order marks are ignored. */
class VoiceLatencyTracker(private val clock: () -> Long = { System.currentTimeMillis() }) {
    enum class Mark { USER_SPEECH_END, FIRST_TRANSCRIPT, FIRST_AUDIO, PLAYBACK_START, TURN_COMPLETE }

    private val times = LongArray(Mark.entries.size) { -1L }
    private var lastIndex = -1

    @Synchronized
    fun mark(m: Mark) {
        val idx = m.ordinal
        if (idx <= lastIndex) return
        times[idx] = clock()
        lastIndex = idx
    }

    @Synchronized
    fun reset() {
        times.fill(-1L)
        lastIndex = -1
    }

    @Synchronized
    fun delta(from: Mark, to: Mark): Long? {
        val a = times[from.ordinal]
        val b = times[to.ordinal]
        return if (a >= 0 && b >= 0 && b >= a) b - a else null
    }

    @Synchronized fun toFirstAudio(): Long? = delta(Mark.USER_SPEECH_END, Mark.FIRST_AUDIO)
    @Synchronized fun toTurnComplete(): Long? = delta(Mark.USER_SPEECH_END, Mark.TURN_COMPLETE)

    companion object {
        private val _reconnectCount = MutableStateFlow(0)
        val reconnectCount: StateFlow<Int> = _reconnectCount
        fun incrementReconnect() { _reconnectCount.value = _reconnectCount.value + 1 }
        fun resetReconnect() { _reconnectCount.value = 0 }
    }
}
