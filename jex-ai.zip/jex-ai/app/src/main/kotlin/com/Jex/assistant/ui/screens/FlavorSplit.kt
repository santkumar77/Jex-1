package com.Jex.assistant.ui.screens

import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController

/** A tile on the Quick Actions screen. Tiles only start real tools. */
data class QuickTile(
    val title: String,
    val phrase: String,
    val icon: ImageVector,
    val onClick: (android.content.Context, NavHostController) -> Unit
)
