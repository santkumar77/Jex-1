package com.Jex.assistant.voice

import android.util.Base64
import com.Jex.assistant.action.JexToolCatalog
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Full-duplex Gemini Live WebSocket client. Never logs the API key, raw server messages, prompts or audio.
 */
class GeminiLiveClient(private val apiKey: String) {

    interface Listener {
        fun onSetupComplete()
        fun onAudioChunk(bytes: ByteArray)
        fun onInputTranscript(text: String)
        fun onOutputTranscript(text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onTurnComplete()
        fun onInterrupted()
        fun onError(message: String)
        fun onClosed()
    }

    var listener: Listener? = null

    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var ready = false
    private val dedup = ToolCallDeduplicator()

    val isReady: Boolean get() = ready && socket != null

    fun connect(systemInstruction: String, voiceName: String = "Aoede", tools: JSONArray? = null) {
        ready = false
        val url = "$WS_URL?key=$apiKey"
        val request = Request.Builder().url(url).build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(buildSetup(systemInstruction, voiceName, tools).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (socket !== webSocket) return
                ready = false
                val code = response?.code
                val msg = when {
                    code == 400 || code == 401 || code == 403 -> "Gemini rejected the API key (HTTP $code). Check your key in Settings."
                    code != null -> "Connection problem (HTTP $code)."
                    else -> "Couldn't reach Gemini. Check your internet."
                }
                listener?.onError(msg)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (socket !== webSocket) return
                ready = false
                listener?.onClosed()
            }
        })
    }

    fun sendAudio(pcm: ByteArray) {
        val ws = socket ?: return
        if (!ready) return
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        val msg = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "audio", JSONObject()
                    .put("mimeType", "audio/pcm;rate=16000")
                    .put("data", b64)
            )
        )
        ws.send(msg.toString())
    }

    /** A camera / screen frame (JPEG) for vision and screen share. */
    fun sendImageFrame(jpeg: ByteArray) {
        val ws = socket ?: return
        if (!ready) return
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val msg = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "video", JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", b64)
            )
        )
        ws.send(msg.toString())
    }

    /** Text typed or injected by the app (for example a notification line to read aloud). */
    fun sendText(text: String) {
        val ws = socket ?: return
        if (!ready) return
        ws.send(JSONObject().put("realtimeInput", JSONObject().put("text", text)).toString())
    }

    fun sendToolResponse(id: String, name: String, result: JSONObject) {
        val ws = socket ?: return
        val fr = JSONObject().put("id", id).put("name", name).put("response", result)
        val msg = JSONObject().put(
            "toolResponse", JSONObject().put("functionResponses", JSONArray().put(fr))
        )
        ws.send(msg.toString())
    }

    fun disconnect() {
        ready = false
        val ws = socket
        socket = null
        try {
            ws?.close(1000, "bye")
        } catch (ignored: Exception) {
        }
    }

    private fun buildSetup(systemInstruction: String, voiceName: String, toolsOverride: JSONArray?): JSONObject {
        val decls = toolsOverride ?: JexToolCatalog.declarations()
        val setup = JSONObject()
            .put("model", MODEL)
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)
                            )
                        )
                    )
            )
            .put(
                "systemInstruction", JSONObject().put(
                    "parts", JSONArray().put(JSONObject().put("text", systemInstruction))
                )
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        if (decls.length() > 0) {
            setup.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
        }
        return JSONObject().put("setup", setup)
    }

    private fun handle(raw: String) {
        val l = listener ?: return
        val root = try {
            JSONObject(raw)
        } catch (ignored: Exception) {
            return
        }
        if (root.has("setupComplete")) {
            ready = true
            l.onSetupComplete()
            return
        }
        root.optJSONObject("toolCall")?.let { tc ->
            val calls = tc.optJSONArray("functionCalls") ?: JSONArray()
            for (i in 0 until calls.length()) {
                val c = calls.optJSONObject(i) ?: continue
                val id = c.optString("id")
                if (!dedup.firstTime(id)) continue
                l.onToolCall(id, c.optString("name"), c.optJSONObject("args") ?: JSONObject())
            }
        }
        val sc = root.optJSONObject("serverContent") ?: return
        sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val mime = inline.optString("mimeType")
                if (mime.startsWith("audio/pcm")) {
                    val data = inline.optString("data")
                    if (data.isNotEmpty()) {
                        l.onAudioChunk(Base64.decode(data, Base64.DEFAULT))
                    }
                }
            }
        }
        sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let(l::onInputTranscript)
        sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let(l::onOutputTranscript)
        if (sc.optBoolean("interrupted")) l.onInterrupted()
        if (sc.optBoolean("turnComplete")) l.onTurnComplete()
    }

    companion object {
        // Keep the Live model name in ONE constant; check the Live API docs for the current native-audio model.
        const val MODEL = "models/gemini-3.1-flash-live-preview"
        const val WS_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
    }
}
