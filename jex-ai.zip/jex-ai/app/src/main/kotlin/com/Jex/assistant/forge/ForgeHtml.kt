package com.Jex.assistant.forge

object ForgeHtml {
    const val SAFETY_MARKER = "data-jex-safety-net"

    fun stripFences(text: String): String {
        var t = text.trim()
        if (t.startsWith("```")) {
            val nl = t.indexOf('\n')
            t = if (nl >= 0) t.substring(nl + 1) else t.removePrefix("```")
        }
        if (t.trimEnd().endsWith("```")) t = t.trimEnd().removeSuffix("```")
        return t.trim()
    }

    fun looksLikeHtml(text: String): Boolean {
        val t = text.trimStart().lowercase()
        return t.startsWith("<!doctype html") || t.startsWith("<html") || (t.contains("<body") && t.contains("<"))
    }

    /** Closes open script/style/body/html tags in a cut-off page. */
    fun repairTruncated(html: String): String {
        var h = html
        val lower = h.lowercase()
        // Drop a dangling, unfinished tag at the very end ("<div cla")
        val lastLt = h.lastIndexOf('<')
        val lastGt = h.lastIndexOf('>')
        if (lastLt > lastGt) h = h.substring(0, lastLt)
        fun open(tag: String) = Regex("<$tag\\b", RegexOption.IGNORE_CASE).findAll(h).count()
        fun close(tag: String) = Regex("</$tag>", RegexOption.IGNORE_CASE).findAll(h).count()
        val sb = StringBuilder(h)
        if (open("script") > close("script")) sb.append("\n</script>")
        if (open("style") > close("style")) sb.append("\n</style>")
        if (lower.contains("<body") && close("body") == 0) sb.append("\n</body>")
        if (lower.contains("<html") && close("html") == 0) sb.append("\n</html>")
        return sb.toString()
    }

    private val SAFETY_SCRIPT = """
<script $SAFETY_MARKER>
(function(){
  if (window.__jexSafety) return; window.__jexSafety = true;
  function skip(el){
    if (!el || el.tagName === 'CANVAS') return true;
    var cs = getComputedStyle(el);
    if (cs.position === 'fixed' || cs.pointerEvents === 'none') return true;
    if (el.closest('[aria-hidden="true"]')) return true;
    return false;
  }
  function check(){
    var vh = window.innerHeight;
    document.querySelectorAll('body *').forEach(function(el){
      if (el.__jexSeen) return;
      var cs = getComputedStyle(el);
      if (parseFloat(cs.opacity) > 0.01) return;
      if (skip(el)) return;
      if (!(el.textContent || '').trim() && !el.querySelector('img,svg,video')) return;
      var r = el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > vh || r.height < 4) return;
      el.__jexSeen = true;
      el.style.transition = 'opacity .6s ease';
      el.style.opacity = '1';
      el.style.transform = 'none';
    });
  }
  setInterval(function(){ setTimeout(check, 1400); }, 700);
  window.addEventListener('scroll', function(){ setTimeout(check, 1400); }, {passive:true});
})();
</script>
""".trimIndent()

    /** Idempotent: injects the safety net once (marker attribute). */
    fun withSafetyNet(html: String): String {
        if (html.contains(SAFETY_MARKER)) return html
        val idx = html.lastIndexOf("</body>", ignoreCase = true)
        return if (idx >= 0) html.substring(0, idx) + SAFETY_SCRIPT + "\n" + html.substring(idx) else html + "\n" + SAFETY_SCRIPT
    }
}
