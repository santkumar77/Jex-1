package com.Jex.assistant.voice

enum class JexOrbState { IDLE, LISTENING, THINKING, SPEAKING, CONNECTING, ERROR }
