package com.Jex.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.data.Personality
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.components.JexTopBar
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalBottomBarInset
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.LocalJexReducedMotion

@Composable
fun PersonalityScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    val reduced = LocalJexReducedMotion.current
    val inset = LocalBottomBarInset.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        JexTopBar("Personality", onBack = { nav.popBackStack() })
        Text("Changes take effect immediately", style = JexType.voice.copy(color = c.textSecondary), modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = inset.calculateBottomPadding() + 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(Personality.entries.toList()) { p ->
                val selected = p == appState.personality
                JexGlassCard(
                    Modifier.fillMaxWidth().scale(if (selected && !reduced) 1.04f else 1f).alpha(if (selected) 1f else 0.82f),
                    onClick = { appState.applyPersonality(p) },
                    elevation = if (selected) 14.dp else 4.dp
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(p.icon, style = JexType.headline)
                        Text(
                            p.displayName, style = JexType.title.copy(color = if (selected) c.accent else c.textPrimary),
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        Text(p.description, style = JexType.caption.copy(color = c.textSecondary))
                    }
                }
            }
        }
    }
}
