package com.Jex.assistant.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import com.Jex.assistant.data.JexAppState

fun NavGraphBuilder.registerAccessibilityDisclosureRoute(nav: NavHostController) {}

@Composable
fun FlavorSettingsRows(appState: JexAppState, nav: NavHostController) {}

@Composable
fun FlavorPermissionRows(tick: Int) {}

@Composable
fun FlavorVoiceExtras(appState: JexAppState, nav: NavHostController) {}

@Composable
fun FlavorDebugSection() {}

fun flavorQuickTiles(): List<QuickTile> = emptyList()
