package com.Jex.assistant.license

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

@Composable
fun AccessKeyBanner(nav: NavHostController) {}

@Composable
fun AccessKeySection() {}
