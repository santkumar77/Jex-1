package com.Jex.assistant.action

import android.content.Context
import com.Jex.assistant.license.AccessKeyManager
import com.Jex.assistant.vision.VisionTools
import org.json.JSONObject

object ActionExecutor {
    suspend fun execute(ctx: Context, name: String, args: JSONObject): JSONObject {
        val app = ctx.applicationContext
        if (!AccessKeyManager.isActive(app)) return ToolResults.status("blocked", AccessKeyManager.blockedMessage(app))
        if (name in VisionTools.NAMES) return VisionTools.execute(app, name, args)
        return when (name) {
            "open_app" -> openApp(app, args.optString("app_name"))
            "call_contact" -> callContact(app, args.optString("name_or_number"))
            "message_contact" -> messageContact(app, args.optString("name_or_number"), args.optString("text"), args.optString("app"))
            else -> ToolResults.unknown(name)
        }
    }

    private suspend fun openApp(ctx: Context, query: String): JSONObject {
        if (query.isBlank()) return ToolResults.error("app_name missing")
        val hit = AppLauncher.findApp(ctx, query) ?: return ToolResults.status("not_found", "No installed app matches '$query'")
        return if (AppLauncher.launch(ctx, hit.second)) JSONObject().put("status", "opened").put("app", hit.first)
        else ToolResults.status("failed", "Couldn't launch ${hit.first}. The phone may block opening apps from the background; ask the user to unlock the screen.")
    }

    private fun callContact(ctx: Context, query: String): JSONObject {
        return when (val r = ContactResolver.lookup(ctx, query)) {
            is ContactResult.NoPermission -> ToolResults.status("needs_contacts_permission", "Ask the user to allow Contacts in Settings > Permissions")
            is ContactResult.NotFound -> ToolResults.status("contact_not_found")
            is ContactResult.Found -> JSONObject().put("status", CommIntents.call(ctx, r.number)).put("contact", r.name)
        }
    }

    private fun messageContact(ctx: Context, query: String, text: String, appPref: String): JSONObject {
        val r = ContactResolver.lookup(ctx, query)
        if (r is ContactResult.NoPermission) return ToolResults.status("needs_contacts_permission")
        if (r !is ContactResult.Found) return ToolResults.status("contact_not_found")
        val useWa = appPref.lowercase().contains("whatsapp") || (appPref.isBlank() && CommIntents.whatsAppPackage(ctx) != null)
        val ok = if (useWa) CommIntents.openWhatsAppComposer(ctx, r.number, text) else CommIntents.openSmsComposer(ctx, r.number, text)
        return JSONObject().put("status", if (ok) "composer_opened_user_must_tap_send" else "failed").put("contact", r.name)
    }
}
