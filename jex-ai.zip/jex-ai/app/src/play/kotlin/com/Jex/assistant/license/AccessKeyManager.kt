package com.Jex.assistant.license

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Play build: no access key. Always active. */
object AccessKeyManager {
    private val _info = MutableStateFlow(LicenseInfo(active = true))
    val info: StateFlow<LicenseInfo> = _info

    fun isActive(ctx: Context): Boolean = true
    fun blockedMessage(ctx: Context): String = ""
    fun refreshInfo(ctx: Context) {}
    suspend fun liveCheck(ctx: Context) {}
}
