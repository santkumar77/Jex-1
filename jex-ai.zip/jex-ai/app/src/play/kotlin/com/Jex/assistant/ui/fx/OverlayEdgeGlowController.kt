package com.Jex.assistant.ui.fx

import android.content.Context

/** Play build: the in-app glow (MainActivity Dialog) is enough; there is no system overlay. */
object OverlayEdgeGlowController {
    fun start(ctx: Context) {}
    fun stop(ctx: Context) {}
}
