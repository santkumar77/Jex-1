package com.Jex.assistant.action

import org.json.JSONArray

/** Play build: only safe, user-visible tools. */
object JexToolCatalog {
    fun declarations(): JSONArray {
        val arr = JSONArray()
        arr.put(functionDecl("open_app", "Open an installed app by its name.", mapOf("app_name" to "Name of the app, e.g. YouTube"), listOf("app_name")))
        arr.put(functionDecl("call_contact", "Call a contact by name or a phone number.", mapOf("name_or_number" to "Contact name or phone number"), listOf("name_or_number")))
        arr.put(
            functionDecl(
                "message_contact", "Open a message composer to a contact. The user taps Send themselves.",
                mapOf("name_or_number" to "Contact name or phone number", "text" to "Message text", "app" to "whatsapp or sms"),
                listOf("name_or_number", "text")
            )
        )
        CommonTools.declarations().forEach { arr.put(it) }
        return arr
    }
}
