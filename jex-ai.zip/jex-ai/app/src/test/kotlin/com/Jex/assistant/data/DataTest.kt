package com.Jex.assistant.data

import com.Jex.assistant.ui.fx.JexOrbStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SettingFallbacksTest {
    @Test fun dataStoreWins() = assertEquals("A", SettingFallbacks.resolve("A", "B", "C"))
    @Test fun prefsFallback() = assertEquals("B", SettingFallbacks.resolve(null, "B", "C"))
    @Test fun blankIgnored() = assertEquals("C", SettingFallbacks.resolve("", " ", "C"))
}

class PersonalityTest {
    @Test fun tenPersonalities() = assertEquals(10, Personality.entries.size)
    @Test fun unknownFallsBackToNormal() = assertEquals(Personality.NORMAL, Personality.fromName("zzz"))
    @Test fun companionModesAreSafe() {
        listOf(Personality.COMPANION, Personality.GF_MODE).forEach {
            val t = it.systemInstruction.lowercase()
            assertTrue(t.contains("never claim to be human"))
            assertTrue(t.contains("sexually explicit"))
        }
    }
    @Test fun orbStyleFallback() = assertEquals(JexOrbStyle.JEX, JexOrbStyle.fromName("x"))
    @Test fun languageFallback() = assertEquals(LanguagePreference.AUTO, LanguagePreference.fromName(null))
}

class ConversationJsonTest {
    @Test fun roundTrip() {
        val c = Conversation(1, "t", listOf(ChatMessage(2, "hi", true), ChatMessage(3, "yo", false)), 99)
        val back = Conversation.listFromJson(Conversation.listToJson(listOf(c)))
        assertEquals(1, back.size)
        assertEquals("yo", back[0].messages[1].text)
    }
    @Test fun badJsonIsEmpty() = assertEquals(0, Conversation.listFromJson("not json").size)
}

/** The product must carry one name. Put legacy names into old-names.txt (one per line) to enforce it. */
class NoOldNameTest {
    @Test fun noLegacyNamesInSources() {
        val list = File("old-names.txt").takeIf { it.exists() }?.readLines()?.map { it.trim() }?.filter { it.isNotEmpty() } ?: return
        val roots = listOf(File("src/main"), File("src/direct"), File("src/play"))
        roots.filter { it.exists() }.forEach { root ->
            root.walkTopDown().filter { it.isFile && (it.extension == "kt" || it.extension == "xml") }.forEach { f ->
                val text = f.readText()
                list.forEach { name -> assertTrue("${f.path} contains legacy name $name", !text.contains(name, ignoreCase = true)) }
            }
        }
    }
}
