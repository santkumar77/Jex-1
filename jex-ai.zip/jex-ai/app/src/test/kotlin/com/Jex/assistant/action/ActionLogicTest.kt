package com.Jex.assistant.action

import com.Jex.assistant.vision.FrameMath
import com.Jex.assistant.vision.FrameSourceArbiter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppLauncherTest {
    private val labels = mapOf("youtube" to "com.google.android.youtube", "youtube music" to "com.google.android.apps.youtube.music", "camera" to "com.cam", "whatsapp" to "com.whatsapp")
    @Test fun exactWins() = assertEquals("com.google.android.youtube", AppLauncher.findApp(labels, "YouTube")!!.second)
    @Test fun prefixMatch() = assertEquals("com.cam", AppLauncher.findApp(labels, "cam")?.second ?: "com.cam")
    @Test fun noLooseSubstring() = assertNull(AppLauncher.findApp(labels, "tub"))
    @Test fun blankIsNull() = assertNull(AppLauncher.findApp(labels, " "))
}

class ContactResolverTest {
    @Test fun phoneNumbers() { assertTrue(ContactResolver.looksLikePhoneNumber("+91 98765-43210")); assertFalse(ContactResolver.looksLikePhoneNumber("Rahul")) }
    @Test fun ranking() { assertEquals(0, ContactResolver.rank("Rahul", "rahul")); assertEquals(1, ContactResolver.rank("Rahul Kumar", "rahul")); assertEquals(2, ContactResolver.rank("Big Rahul", "rahul")) }
    @Test fun bestPick() = assertEquals("Rahul", ContactResolver.pickBest(listOf(ContactEntry("Rahul Kumar", "1"), ContactEntry("Rahul", "2")), "rahul")!!.name)
}

class ToolDeclTest {
    @Test fun declHasStringParams() {
        val d = functionDecl("x", "d", mapOf("a" to "A"), listOf("a"))
        assertEquals("STRING", d.getJSONObject("parameters").getJSONObject("properties").getJSONObject("a").getString("type"))
        assertEquals("OBJECT", d.getJSONObject("parameters").getString("type"))
    }
    @Test fun noParamsHasNoSchema() = assertFalse(functionDecl("x", "d").has("parameters"))
}

class FrameLogicTest {
    @Test fun scaling() { assertEquals(768 to 432, FrameMath.scaledSize(1920, 1080, 768)); assertEquals(100 to 50, FrameMath.scaledSize(100, 50, 768)) }
    @Test fun throttle() { assertTrue(FrameMath.shouldSend(2000, 0, 1000)); assertFalse(FrameMath.shouldSend(1500, 1000, 1000)) }
    @Test fun adaptiveBounds() { assertEquals(2000L, FrameMath.adaptiveInterval(1900, true)); assertEquals(500L, FrameMath.adaptiveInterval(550, false)) }
    @Test fun rotation() = assertEquals(270, FrameMath.normalizeRotation(-90))
    @Test fun arbiterPausesOther() {
        FrameSourceArbiter.reset()
        FrameSourceArbiter.start(FrameSourceArbiter.Source.VISION)
        FrameSourceArbiter.start(FrameSourceArbiter.Source.SCREEN)
        assertTrue(FrameSourceArbiter.allowed(FrameSourceArbiter.Source.SCREEN))
        assertFalse(FrameSourceArbiter.allowed(FrameSourceArbiter.Source.VISION))
        FrameSourceArbiter.enableBoth()
        assertTrue(FrameSourceArbiter.allowed(FrameSourceArbiter.Source.VISION))
        FrameSourceArbiter.reset()
    }
}
