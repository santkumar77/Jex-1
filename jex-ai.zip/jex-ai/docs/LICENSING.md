# Access key backend (direct flavor)

The direct build asks for an access key. Your backend must expose two HTTPS endpoints (JSON in, JSON out),
authenticated with `Authorization: Bearer <api_key>` from `license-config.properties`.

`POST {base_url}/activate` and `POST {base_url}/check`

Request: `{"key": "...", "device_id": "uuid"}`

Response: `{"valid": true, "plan": "pro", "expires_at": 1767225600000, "blocked": false, "message": ""}`

* `expires_at` is epoch milliseconds, `0` means no expiry.
* `blocked: true` immediately disables the app on the next resume.
* When the server is unreachable the app keeps trusting the last answer until `expires_at`.
* Without `license-config.properties` the release build reports "Licensing is not configured" and refuses to run;
  **debug builds stay usable** so you can develop.
