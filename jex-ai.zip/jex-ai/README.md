# Jex AI

Voice-first Android assistant (Kotlin, Jetpack Compose, Gemini Live) built from the Jex build guide.
Made by जसवंत डेहरिया.

* Two flavors: `direct` (full phone control, access key) and `play` (Play-safe).
* Features: Gemini Live voice with barge-in and echo guard, 10 personalities, Hindi/Hinglish/English, typed chat,
  Website Forge (3D build screen + streamed Gemini site generation), Vision Mode, screen share, notification reader,
  form guide, multi-step task engine, social/WhatsApp agents, AI call agent.

See `docs/BUILD.md` to build and `docs/LICENSING.md` for the direct build's access key backend.
